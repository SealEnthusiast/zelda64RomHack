#ifndef OBJECT_GI_BOTTLE_LETTER_H
#define OBJECT_GI_BOTTLE_LETTER_H 1

extern Vtx object_gi_bottle_letterVtx_000000[];
extern Gfx gGiLetterBottleContentsDL[];
extern Gfx gGiLetterBottleDL[];

#endif

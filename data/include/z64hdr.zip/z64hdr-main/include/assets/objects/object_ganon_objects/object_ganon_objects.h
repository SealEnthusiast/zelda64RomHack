#ifndef OBJECT_GANON_OBJECTS_H
#define OBJECT_GANON_OBJECTS_H 1

extern Vtx object_ganon_objectsVtx_000000[];
extern Gfx object_ganon_objects_DL_0000C0[];
extern u64 object_ganon_objects_Tex_000170[];

#endif

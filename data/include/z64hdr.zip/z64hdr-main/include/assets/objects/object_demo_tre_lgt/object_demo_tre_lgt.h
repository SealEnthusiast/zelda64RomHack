#ifndef OBJECT_DEMO_TRE_LGT_H
#define OBJECT_DEMO_TRE_LGT_H 1

extern u8 gWarpDemoTreLgtBlob_000000[];

#endif

#ifndef OBJECT_MASTERGOLON_H
#define OBJECT_MASTERGOLON_H 1

extern s16 sGoronShopkeeperAnimFrameData[];
extern JointIndex sGoronShopkeeperAnimJointIndices[];
extern AnimationHeader gGoronShopkeeperAnim;

#endif

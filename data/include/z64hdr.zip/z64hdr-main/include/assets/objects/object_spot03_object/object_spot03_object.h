#ifndef OBJECT_SPOT03_OBJECT_H
#define OBJECT_SPOT03_OBJECT_H 1

extern u64 object_spot03_object_Tex_000000[];
extern Vtx object_spot03_object_Vtx_000800[];
extern Vtx object_spot03_object_Vtx_000990[];
extern Gfx object_spot03_object_DL_000B20[];
extern Gfx object_spot03_object_DL_000BC0[];
extern CamData object_spot03_object_Col_000C98CamDataList[];
extern SurfaceType object_spot03_object_Col_000C98SurfaceType[];
extern CollisionPoly object_spot03_object_Col_000C98Polygons[];
extern Vec3s object_spot03_object_Col_000C98Vertices[];
extern CollisionHeader object_spot03_object_Col_000C98;
extern u64 object_spot03_object_Tex_000CD0[];
extern Vtx object_spot03_objectVtx_0014D0[];
extern Gfx object_spot03_object_DL_001580[];

#endif

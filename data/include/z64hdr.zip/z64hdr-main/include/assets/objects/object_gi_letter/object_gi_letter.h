#ifndef OBJECT_GI_LETTER_H
#define OBJECT_GI_LETTER_H 1

extern u64 object_gi_letterTex_000000[];
extern u64 object_gi_letterTex_000600[];
extern Vtx object_gi_letterVtx_000C00[];
extern Gfx gGiLetterDL[];
extern Gfx gGiLetterWritingDL[];

#endif

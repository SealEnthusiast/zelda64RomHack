#ifndef OBJECT_OUKE_HAKA_H
#define OBJECT_OUKE_HAKA_H 1

extern Vtx object_ouke_hakaVtx_000000[];
extern Gfx object_ouke_haka_DL_0000C0[];
extern u64 object_ouke_haka_Tex_000170[];

#endif

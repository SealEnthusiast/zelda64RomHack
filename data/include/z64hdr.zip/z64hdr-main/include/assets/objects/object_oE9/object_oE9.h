#ifndef OBJECT_OE9_H
#define OBJECT_OE9_H 1

extern Vtx object_oE9Vtx_000000[];
extern Gfx object_oE9_DL_000800[];
extern u64 object_oE9_TLUT_000C90[];
extern u64 object_oE9_Tex_000E90[];
extern u8 object_oE9_Blob_001290[];
extern u64 object_oE9_TLUT_001A90[];
extern u64 object_oE9_Tex_001C90[];
extern u64 object_oE9_Tex_001CD0[];
extern u64 object_oE9_Tex_001DD0[];
extern u64 object_oE9_Tex_001ED0[];
extern u64 object_oE9_Tex_0026D0[];
extern u64 object_oE9_Tex_002ED0[];

#endif

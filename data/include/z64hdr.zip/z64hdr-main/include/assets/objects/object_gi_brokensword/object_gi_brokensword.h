#ifndef OBJECT_GI_BROKENSWORD_H
#define OBJECT_GI_BROKENSWORD_H 1

extern Vtx object_gi_brokenswordVtx_000000[];
extern Gfx gGiBrokenGoronSwordDL[];

#endif

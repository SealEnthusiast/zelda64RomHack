#ifndef OBJECT_GI_GODDESS_H
#define OBJECT_GI_GODDESS_H 1

extern Vtx object_gi_goddessVtx_000000[];
extern Gfx gGiMagicSpellDiamondDL[];
extern Gfx gGiDinsFireColorDL[];
extern Gfx gGiFaroresWindColorDL[];
extern Gfx gGiNayrusLoveColorDL[];
extern Gfx gGiMagicSpellOrbDL[];

#endif

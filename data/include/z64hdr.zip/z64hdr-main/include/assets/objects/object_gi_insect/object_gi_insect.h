#ifndef OBJECT_GI_INSECT_H
#define OBJECT_GI_INSECT_H 1

extern Vtx object_gi_insectVtx_000000[];
extern Gfx gGiBugsContainerDL[];
extern Gfx gGiBugsGlassDL[];

#endif

#ifndef OBJECT_MASTERZOORA_H
#define OBJECT_MASTERZOORA_H 1

extern s16 sZoraShopkeeperAnimFrameData[];
extern JointIndex sZoraShopkeeperAnimJointIndices[];
extern AnimationHeader gZoraShopkeeperAnim;

#endif

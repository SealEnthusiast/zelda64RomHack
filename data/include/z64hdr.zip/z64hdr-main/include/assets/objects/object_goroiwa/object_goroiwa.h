#ifndef OBJECT_GOROIWA_H
#define OBJECT_GOROIWA_H 1

extern Vtx object_goroiwaVtx_000000[];
extern Gfx gRollingRockDL[];
extern u64 gRollingRockTex[];

#endif

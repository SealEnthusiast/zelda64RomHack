#ifndef OBJECT_KANBAN_H
#define OBJECT_KANBAN_H 1

extern Vtx object_kanbanVtx_000000[];
extern Gfx object_kanban_DL_000C30[];
extern Gfx object_kanban_DL_000CB0[];
extern Gfx object_kanban_DL_000DB8[];
extern Gfx object_kanban_DL_000E78[];
extern Gfx object_kanban_DL_000F38[];
extern Gfx object_kanban_DL_000FF8[];
extern Gfx object_kanban_DL_0010B8[];
extern Gfx object_kanban_DL_0011C0[];
extern Gfx object_kanban_DL_0012C8[];
extern Gfx object_kanban_DL_0013D0[];
extern Gfx object_kanban_DL_001488[];
extern Gfx object_kanban_DL_001540[];
extern Vtx object_kanbanVtx_001600[];
extern Gfx object_kanban_DL_001630[];
extern u64 object_kanban_Tex_0016B0[];

#endif

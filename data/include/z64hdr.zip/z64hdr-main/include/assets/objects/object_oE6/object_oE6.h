#ifndef OBJECT_OE6_H
#define OBJECT_OE6_H 1

extern Vtx object_oE6Vtx_000000[];
extern Gfx object_oE6_DL_000AE0[];
extern u64 object_oE6_TLUT_000FD0[];
extern u64 object_oE6_Tex_0011D0[];
extern u8 object_oE6_Blob_0015D0[];
extern u64 object_oE6_TLUT_001DD0[];
extern u64 object_oE6_Tex_001FD0[];
extern u64 object_oE6_Tex_002010[];
extern u64 object_oE6_Tex_002110[];
extern u64 object_oE6_Tex_002210[];
extern u64 object_oE6_Tex_002A10[];
extern u64 object_oE6_Tex_002E10[];

#endif

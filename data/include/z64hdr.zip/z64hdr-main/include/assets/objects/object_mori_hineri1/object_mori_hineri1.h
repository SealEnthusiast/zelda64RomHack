#ifndef OBJECT_MORI_HINERI1_H
#define OBJECT_MORI_HINERI1_H 1

extern Vtx object_mori_hineri1Vtx_000000[];
extern Gfx object_mori_hineri1_DL_0024E0[];
extern CamData object_mori_hineri1_Col_0054B8CamDataList[];
extern SurfaceType object_mori_hineri1_Col_0054B8SurfaceType[];
extern CollisionPoly object_mori_hineri1_Col_0054B8Polygons[];
extern Vec3s object_mori_hineri1_Col_0054B8Vertices[];
extern CollisionHeader object_mori_hineri1_Col_0054B8;

#endif

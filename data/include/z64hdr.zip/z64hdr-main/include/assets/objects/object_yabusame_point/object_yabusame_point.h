#ifndef OBJECT_YABUSAME_POINT_H
#define OBJECT_YABUSAME_POINT_H 1

extern u64 object_yabusame_point_Tex_000000[];
extern u64 object_yabusame_point_Tex_000480[];
extern u64 object_yabusame_point_Tex_000900[];
extern Vtx object_yabusame_pointVtx_000D80[];
extern Gfx object_yabusame_point_DL_000DC0[];

#endif

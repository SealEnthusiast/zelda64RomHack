#ifndef OBJECT_GI_SHIELD_3_H
#define OBJECT_GI_SHIELD_3_H 1

extern u64 object_gi_shield_3Tex_000000[];
extern u64 object_gi_shield_3Tex_000400[];
extern Vtx object_gi_shield_3Vtx_000C00[];
extern Gfx gGiMirrorShieldDL[];
extern Gfx gGiMirrorShieldSymbolDL[];

#endif

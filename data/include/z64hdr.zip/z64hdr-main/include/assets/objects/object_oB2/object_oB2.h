#ifndef OBJECT_OB2_H
#define OBJECT_OB2_H 1

extern StandardLimb object_oB2_Limb_000000;
extern StandardLimb object_oB2_Limb_00000C;
extern StandardLimb object_oB2_Limb_000018;
extern StandardLimb object_oB2_Limb_000024;
extern StandardLimb object_oB2_Limb_000030;
extern StandardLimb object_oB2_Limb_00003C;
extern StandardLimb object_oB2_Limb_000048;
extern StandardLimb object_oB2_Limb_000054;
extern StandardLimb object_oB2_Limb_000084;
extern StandardLimb object_oB2_Limb_000090;
extern StandardLimb object_oB2_Limb_00009C;
extern StandardLimb object_oB2_Limb_0000A8;
extern StandardLimb object_oB2_Limb_0000E4;
extern StandardLimb object_oB2_Limb_0000F0;
extern StandardLimb object_oB2_Limb_0000FC;
extern StandardLimb object_oB2_Limb_000114;
extern StandardLimb object_oB2_Limb_000120;
extern StandardLimb object_oB2_Limb_00012C;
extern StandardLimb object_oB2_Limb_000138;
extern StandardLimb object_oB2_Limb_000168;
extern StandardLimb object_oB2_Limb_000174;
extern StandardLimb object_oB2_Limb_000180;
extern StandardLimb object_oB2_Limb_00018C;
extern Vtx object_oB2Vtx_000268[];
extern Gfx object_oB2_DL_001F68[];
extern Gfx object_oB2_DL_0021D0[];
extern Gfx object_oB2_DL_002450[];
extern Gfx object_oB2_DL_0025B8[];
extern Gfx object_oB2_DL_002678[];
extern Gfx object_oB2_DL_002758[];
extern Gfx object_oB2_DL_0028B8[];
extern Gfx object_oB2_DL_002978[];
extern u64 object_oB2_Tex_002A58[];
extern u64 object_oB2_Tex_002C58[];
extern u64 object_oB2_Tex_002CD8[];
extern u64 object_oB2_Tex_0030D8[];
extern u64 object_oB2_Tex_0031D8[];
extern u64 object_oB2_Tex_0039D8[];
extern u64 object_oB2_Tex_003BD8[];
extern u64 object_oB2_Tex_003C58[];
extern u64 object_oB2_Tex_003E58[];
extern u64 object_oB2_Tex_004058[];

#endif

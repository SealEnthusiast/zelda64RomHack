#ifndef OBJECT_B_HEART_H
#define OBJECT_B_HEART_H 1

extern Vtx object_b_heartVtx_000000[];
extern Gfx object_b_heart_DL_000240[];
extern Gfx object_b_heart_DL_000348[];
extern u64 object_b_heart_Tex_0003C0[];
extern u64 object_b_heart_Tex_0005C0[];

#endif

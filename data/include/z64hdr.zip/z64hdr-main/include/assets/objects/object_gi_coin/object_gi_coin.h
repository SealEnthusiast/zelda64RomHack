#ifndef OBJECT_GI_COIN_H
#define OBJECT_GI_COIN_H 1

extern Vtx object_gi_coinVtx_000000[];
extern Gfx gGiYellowCoinColorDL[];
extern Gfx gGiRedCoinColorDL[];
extern Gfx gGiGreenCoinColorDL[];
extern Gfx gGiBlueCoinColorDL[];
extern Gfx gGiCoinDL[];
extern Gfx gGiNDL[];

#endif

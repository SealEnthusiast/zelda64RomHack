#ifndef OBJECT_GND_MAGIC_H
#define OBJECT_GND_MAGIC_H 1

extern u64 object_gnd_magic_Tex_000000[];
extern u64 object_gnd_magic_Tex_000800[];
extern Vtx object_gnd_magicVtx_001000[];
extern Gfx object_gnd_magic_DL_001190[];

#endif

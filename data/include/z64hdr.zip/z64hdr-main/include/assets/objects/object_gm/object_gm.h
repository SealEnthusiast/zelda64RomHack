#ifndef OBJECT_GM_H
#define OBJECT_GM_H 1

extern s16 object_gm_Anim_0002B8FrameData[];
extern JointIndex object_gm_Anim_0002B8JointIndices[];
extern AnimationHeader object_gm_Anim_0002B8;

#endif

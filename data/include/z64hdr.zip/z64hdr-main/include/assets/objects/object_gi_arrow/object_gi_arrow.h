#ifndef OBJECT_GI_ARROW_H
#define OBJECT_GI_ARROW_H 1

extern Vtx object_gi_arrowVtx_000000[];
extern Gfx gGiArrowSmallDL[];
extern Vtx object_gi_arrowVtx_000520[];
extern Gfx gGiArrowMediumDL[];
extern Vtx object_gi_arrowVtx_000DE0[];
extern Gfx gGiArrowLargeDL[];

#endif

#ifndef OBJECT_LIGHTSWITCH_H
#define OBJECT_LIGHTSWITCH_H 1

extern Vtx object_lightswitchVtx_000000[];
extern Gfx object_lightswitch_DL_000260[];
extern Gfx object_lightswitch_DL_000398[];
extern Gfx object_lightswitch_DL_000408[];
extern u64 object_lightswitch_Tex_000420[];
extern u64 object_lightswitch_Tex_000C20[];
extern u64 object_lightswitch_Tex_001420[];
extern u64 object_lightswitch_Tex_001C20[];

#endif

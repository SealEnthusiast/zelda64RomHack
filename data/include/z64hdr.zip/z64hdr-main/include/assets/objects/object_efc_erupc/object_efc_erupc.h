#ifndef OBJECT_EFC_ERUPC_H
#define OBJECT_EFC_ERUPC_H 1

extern u64 object_efc_erupc_Tex_000000[];
extern u64 object_efc_erupc_Tex_000800[];
extern Vtx object_efc_erupcVtx_001000[];
extern Gfx object_efc_erupc_DL_001720[];
extern u64 object_efc_erupc_Tex_001A30[];
extern Vtx object_efc_erupcVtx_002230[];
extern Gfx object_efc_erupc_DL_002570[];
extern Vtx object_efc_erupcVtx_002730[];
extern Gfx object_efc_erupc_DL_002760[];
extern Gfx object_efc_erupc_DL_0027D8[];
extern u64 object_efc_erupc_Tex_0027F0[];

#endif

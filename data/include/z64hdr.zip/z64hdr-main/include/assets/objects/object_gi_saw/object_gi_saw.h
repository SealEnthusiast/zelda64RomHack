#ifndef OBJECT_GI_SAW_H
#define OBJECT_GI_SAW_H 1

extern Vtx object_gi_sawVtx_000000[];
extern Gfx gGiSawDL[];

#endif

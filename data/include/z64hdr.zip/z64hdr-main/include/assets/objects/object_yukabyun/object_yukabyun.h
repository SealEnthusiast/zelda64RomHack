#ifndef OBJECT_YUKABYUN_H
#define OBJECT_YUKABYUN_H 1

extern u64 gFloorTileEnemyBottomTex[];
extern Vtx object_yukabyunVtx_000800[];
extern Gfx gFloorTileEnemyDL[];
extern Vtx object_yukabyunVtx_000A30[];
extern Gfx gFloorTileEnemyFragmentDL[];
extern u64 gFloorTileEnemyTopTex[];
extern u64 gFloorTileEnemyFragmentTex[];

#endif

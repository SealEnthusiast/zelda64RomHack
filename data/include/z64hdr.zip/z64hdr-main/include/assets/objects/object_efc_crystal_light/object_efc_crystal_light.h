#ifndef OBJECT_EFC_CRYSTAL_LIGHT_H
#define OBJECT_EFC_CRYSTAL_LIGHT_H 1

extern u64 gCrystalLightTex[];
extern Vtx object_efc_crystal_lightVtx_000800[];
extern Gfx gCrystalLightDL[];

#endif

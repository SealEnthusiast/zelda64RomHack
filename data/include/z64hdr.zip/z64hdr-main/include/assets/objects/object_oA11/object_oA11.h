#ifndef OBJECT_OA11_H
#define OBJECT_OA11_H 1

extern StandardLimb object_oA11_Limb_000000;
extern StandardLimb object_oA11_Limb_00000C;
extern StandardLimb object_oA11_Limb_000018;
extern StandardLimb object_oA11_Limb_000024;
extern StandardLimb object_oA11_Limb_000030;
extern StandardLimb object_oA11_Limb_00003C;
extern StandardLimb object_oA11_Limb_000048;
extern StandardLimb object_oA11_Limb_000054;
extern StandardLimb object_oA11_Limb_000084;
extern StandardLimb object_oA11_Limb_000090;
extern StandardLimb object_oA11_Limb_00009C;
extern StandardLimb object_oA11_Limb_0000A8;
extern StandardLimb object_oA11_Limb_0000E4;
extern StandardLimb object_oA11_Limb_0000F0;
extern StandardLimb object_oA11_Limb_0000FC;
extern StandardLimb object_oA11_Limb_000114;
extern StandardLimb object_oA11_Limb_000120;
extern StandardLimb object_oA11_Limb_00012C;
extern StandardLimb object_oA11_Limb_000138;
extern StandardLimb object_oA11_Limb_000144;
extern StandardLimb object_oA11_Limb_000150;
extern StandardLimb object_oA11_Limb_00015C;
extern StandardLimb object_oA11_Limb_000168;
extern StandardLimb object_oA11_Limb_000174;
extern StandardLimb object_oA11_Limb_000180;
extern StandardLimb object_oA11_Limb_00018C;
extern StandardLimb object_oA11_Limb_000198;
extern StandardLimb object_oA11_Limb_0001A4;
extern StandardLimb object_oA11_Limb_0001B0;
extern StandardLimb object_oA11_Limb_0001BC;
extern Vtx object_oA11Vtx_000268[];
extern Gfx object_oA11_DL_000A58[];
extern Gfx object_oA11_DL_000BA8[];
extern Gfx object_oA11_DL_000C40[];
extern Gfx object_oA11_DL_000D28[];
extern Gfx object_oA11_DL_000DD0[];
extern Gfx object_oA11_DL_000EF0[];
extern Gfx object_oA11_DL_000FD8[];
extern u64 object_oA11_Tex_001080[];
extern u64 object_oA11_Tex_001100[];
extern u64 object_oA11_Tex_001140[];
extern u64 object_oA11_Tex_001540[];

#endif

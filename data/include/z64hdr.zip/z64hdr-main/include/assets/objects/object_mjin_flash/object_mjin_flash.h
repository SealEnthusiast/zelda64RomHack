#ifndef OBJECT_MJIN_FLASH_H
#define OBJECT_MJIN_FLASH_H 1

extern u64 gLightMedallionPlatformTex[];

#endif

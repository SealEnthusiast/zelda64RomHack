#ifndef OBJECT_OA9_H
#define OBJECT_OA9_H 1

extern Vtx object_oA9Vtx_000000[];
extern Gfx object_oA9_DL_00000250[];
extern u64 object_oA9_Tex_000003A0[];
extern u64 object_oA9_Tex_000004A0[];

#endif

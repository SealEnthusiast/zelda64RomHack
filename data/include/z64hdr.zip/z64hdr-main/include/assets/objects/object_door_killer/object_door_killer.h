#ifndef OBJECT_DOOR_KILLER_H
#define OBJECT_DOOR_KILLER_H 1

extern Vtx object_door_killerVtx_000000[];
extern Gfx object_door_killer_DL_000A20[];
extern Gfx object_door_killer_DL_000AD8[];
extern Gfx object_door_killer_DL_000BB0[];
extern Gfx object_door_killer_DL_000C88[];
extern Gfx object_door_killer_DL_000D60[];
extern Gfx object_door_killer_DL_000E38[];
extern Gfx object_door_killer_DL_000F10[];
extern Gfx object_door_killer_DL_000FE8[];
extern Vtx object_door_killerVtx_0010D0[];
extern Gfx object_door_killer_DL_001250[];
extern Vtx object_door_killerVtx_001310[];
extern Gfx object_door_killer_DL_001550[];
extern Vtx object_door_killerVtx_001638[];
extern Gfx object_door_killer_DL_0017B8[];
extern Vtx object_door_killerVtx_001878[];
extern Gfx object_door_killer_DL_001A58[];
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B28;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B38;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B48;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B58;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B68;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B78;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B88;
extern StandardLimb object_door_killer_Skel_001BC8LimbsLimb_001B98;
extern void* object_door_killer_Skel_001BC8Limbs[];
extern FlexSkeletonHeader object_door_killer_Skel_001BC8;

#endif

#ifndef OBJECT_GI_PURSE_H
#define OBJECT_GI_PURSE_H 1

extern u64 object_gi_purseTex_000000[];
extern Vtx object_gi_purseVtx_001000[];
extern Gfx gGiAdultWalletColorDL[];
extern Gfx gGiGiantsWalletColorDL[];
extern Gfx gGiAdultWalletRupeeOuterColorDL[];
extern Gfx gGiAdultWalletStringColorDL[];
extern Gfx gGiAdultWalletRupeeInnerColorDL[];
extern Gfx gGiGiantsWalletRupeeOuterColorDL[];
extern Gfx gGiGiantsWalletStringColorDL[];
extern Gfx gGiGiantsWalletRupeeInnerColorDL[];
extern Gfx gGiWalletDL[];
extern Gfx gGiWalletRupeeOuterDL[];
extern Gfx gGiWalletStringDL[];
extern Gfx gGiWalletRupeeInnerDL[];

#endif

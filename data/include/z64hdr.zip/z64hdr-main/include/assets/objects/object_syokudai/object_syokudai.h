#ifndef OBJECT_SYOKUDAI_H
#define OBJECT_SYOKUDAI_H 1

extern Vtx object_syokudaiVtx_000000[];
extern Gfx gGoldenTorchDL[];
extern Vtx object_syokudaiVtx_000570[];
extern Gfx gWoodenTorchDL[];
extern Vtx object_syokudaiVtx_0009D0[];
extern Gfx gTimedTorchDL[];
extern u64 gGoldenTorch1Tex[];
extern u64 gGoldenTorch2Tex[];
extern u64 gTorchFlameGuardTex[];
extern u64 gTimedTorchTex[];
extern u64 gWoodenTorchTex[];

#endif

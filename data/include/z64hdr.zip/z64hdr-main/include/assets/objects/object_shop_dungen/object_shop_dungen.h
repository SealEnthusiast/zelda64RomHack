#ifndef OBJECT_SHOP_DUNGEN_H
#define OBJECT_SHOP_DUNGEN_H 1

extern Vtx object_shop_dungenVtx_000000[];
extern Gfx gShopDungenWoodenShelvesDL[];
extern u64 gShopDungenStoneTLUT[];
extern u64 gShopDungenStone1Tex[];
extern u64 gShopDungenStone2Tex[];
extern Vtx object_shop_dungenVtx_001E08[];
extern Gfx gShopDungenStoneShelvesDL[];
extern u64 gShopDungenWoodPlankTex[];

#endif

#ifndef OBJECT_SPOT16_OBJ_H
#define OBJECT_SPOT16_OBJ_H 1

extern u64 gDodongosCavernRockTex[];
extern Vtx object_spot16_objVtx_000800[];
extern Gfx gDodongosCavernRockDL[];
extern Gfx gDodongosCavernRock2DL[];
extern Gfx gDodongosCavernRock3DL[];
extern u64 gDeathMountainRingTex[];
extern Vtx object_spot16_objVtx_001430[];
extern Gfx gDeathMountainRingDL[];

#endif

#ifndef OBJECT_DEKUJR_H
#define OBJECT_DEKUJR_H 1

extern u64 object_dekujr_Tex_000000[];
extern u64 object_dekujr_Tex_000800[];
extern u64 object_dekujr_Tex_001000[];
extern u64 object_dekujr_Tex_001400[];
extern u64 object_dekujr_Tex_001600[];
extern u64 object_dekujr_Tex_001640[];
extern u64 object_dekujr_Tex_002640[];
extern Vtx object_dekujrVtx_002A40[];
extern Gfx object_dekujr_DL_0030D0[];
extern Gfx object_dekujr_DL_0032D8[];

#endif

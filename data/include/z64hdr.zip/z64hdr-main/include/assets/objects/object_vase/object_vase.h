#ifndef OBJECT_VASE_H
#define OBJECT_VASE_H 1

extern Gfx gUnusedVaseDL[];
extern Vtx object_vaseVtx_0001A0[];
extern u64 gUnusedVaseBodyTex[];
extern u64 gUnusedVaseTopTex[];

#endif

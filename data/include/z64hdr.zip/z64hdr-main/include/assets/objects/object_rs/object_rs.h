#ifndef OBJECT_RS_H
#define OBJECT_RS_H 1

extern s16 object_rs_Anim_00065CFrameData[];
extern JointIndex object_rs_Anim_00065CJointIndices[];
extern AnimationHeader object_rs_Anim_00065C;
extern Vtx object_rsVtx_000670[];
extern Gfx object_rs_DL_001FA0[];
extern Gfx object_rs_DL_0021F8[];
extern Gfx object_rs_DL_0025F8[];
extern Gfx object_rs_DL_002730[];
extern Gfx object_rs_DL_002860[];
extern Gfx object_rs_DL_002A70[];
extern Gfx object_rs_DL_002BA8[];
extern Gfx object_rs_DL_002CD8[];
extern u64 object_rs_TLUT_002EE8[];
extern u64 object_rs_Tex_0030E8[];
extern u64 object_rs_Tex_003128[];
extern u64 object_rs_Tex_003168[];
extern u64 gBombchuShopkeeperEyeOpenTex[];
extern u64 gBombchuShopkeeperEyeHalfTex[];
extern u64 gBombchuShopkeeperEyeClosedTex[];
extern u64 object_rs_Tex_004568[];
extern u64 object_rs_Tex_004668[];
extern u64 object_rs_Tex_0046E8[];
extern StandardLimb object_rs_Limb_0047E8;
extern StandardLimb object_rs_Limb_0047F4;
extern StandardLimb object_rs_Limb_004800;
extern StandardLimb object_rs_Limb_00480C;
extern StandardLimb object_rs_Limb_004818;
extern StandardLimb object_rs_Limb_004824;
extern StandardLimb object_rs_Limb_004830;
extern StandardLimb object_rs_Limb_00483C;
extern void* object_rs_Skel_004868Limbs[];
extern FlexSkeletonHeader object_rs_Skel_004868;

#endif

#ifndef OBJECT_TRAP_H
#define OBJECT_TRAP_H 1

extern u64 gSlidingBladeTrapTex_0000[];
extern u64 gSlidingBladeTrapBoltsTex[];
extern u64 gSlidingBladeTrapGradientTex[];
extern Vtx object_trapVtx_000C00[];
extern Gfx gSlidingBladeTrapDL[];
extern Gfx gLandmineBillboardDL[];
extern Vtx object_trapVtx_0016C8[];
extern Gfx gUnusedSpikeDL[];
extern Vtx object_trapVtx_001878[];
extern u64 gLandmineBillboardTex[];

#endif

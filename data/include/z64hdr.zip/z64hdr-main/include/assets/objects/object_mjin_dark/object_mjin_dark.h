#ifndef OBJECT_MJIN_DARK_H
#define OBJECT_MJIN_DARK_H 1

extern u64 gShadowMedallionPlatformTex[];

#endif

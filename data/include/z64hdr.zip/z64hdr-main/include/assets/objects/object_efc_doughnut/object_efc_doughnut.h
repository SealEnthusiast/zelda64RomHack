#ifndef OBJECT_EFC_DOUGHNUT_H
#define OBJECT_EFC_DOUGHNUT_H 1

extern u64 gDeathMountainCloudFireTex[];
extern Vtx object_efc_doughnutVtx_000200[];
extern Gfx gDeathMountainCloudCircleFieryDL[];
extern u64 gDeathMountainCloudNormalTex[];
extern Vtx object_efc_doughnutVtx_000F80[];
extern Gfx gDeathMountainCloudCircleNormalDL[];

#endif

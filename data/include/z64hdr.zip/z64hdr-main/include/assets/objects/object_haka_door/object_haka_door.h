#ifndef OBJECT_HAKA_DOOR_H
#define OBJECT_HAKA_DOOR_H 1

extern u64 object_haka_door_Tex_000000[];
extern Vtx object_haka_doorVtx_001000[];
extern Gfx object_haka_door_DL_001310[];
extern Gfx gShadowDoorLeftDL[];
extern Gfx gShadowDoorRightDL[];
extern u64 object_haka_door_Tex_001490[];
extern Vtx object_haka_doorVtx_002490[];
extern Gfx object_haka_door_DL_002620[];
extern u64 object_haka_door_Tex_002700[];
extern Vtx object_haka_doorVtx_003700[];
extern Gfx object_haka_door_DL_003890[];

#endif

#ifndef OBJECT_DEMO_6K_H
#define OBJECT_DEMO_6K_H 1

extern u64 object_demo_6k_Tex_000000[];
extern Vtx object_demo_6kVtx_001000[];
extern Gfx object_demo_6k_DL_001040[];
extern u64 object_demo_6k_Tex_0010D0[];
extern Vtx object_demo_6kVtx_0018D0[];
extern Gfx object_demo_6k_DL_0022B0[];
extern u64 object_demo_6k_Tex_0025E0[];
extern Vtx object_demo_6kVtx_0035E0[];
extern Gfx object_demo_6k_DL_0039D0[];

#endif

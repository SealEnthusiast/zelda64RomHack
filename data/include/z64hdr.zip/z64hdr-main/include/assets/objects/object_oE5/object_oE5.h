#ifndef OBJECT_OE5_H
#define OBJECT_OE5_H 1

extern Vtx object_oE5Vtx_000268[];
extern Gfx object_oE5_DL_0024E8[];
extern Gfx object_oE5_DL_002690[];
extern Gfx object_oE5_DL_002C60[];
extern Gfx object_oE5_DL_002E10[];
extern Gfx object_oE5_DL_002F00[];
extern Gfx object_oE5_DL_003050[];
extern Gfx object_oE5_DL_003200[];
extern Gfx object_oE5_DL_0032F0[];
extern u64 object_oE5_TLUT_003440[];
extern u64 object_oE5_Tex_003640[];
extern u8 object_oE5_Blob_003A40[];
extern u64 object_oE5_TLUT_004240[];
extern u64 object_oE5_Tex_004440[];
extern u64 object_oE5_Tex_004480[];
extern u64 object_oE5_Tex_004580[];
extern u64 object_oE5_Tex_004680[];
extern u64 object_oE5_Tex_004A80[];
extern u64 object_oE5_Tex_004B80[];
extern u64 object_oE5_Tex_004BC0[];
extern u64 object_oE5_Tex_0053C0[];
extern u64 object_oE5_Tex_0054C0[];

#endif

#ifndef OBJECT_MORI_TEX_H
#define OBJECT_MORI_TEX_H 1

extern u8 object_moriTex_Blob_000000[];

#endif

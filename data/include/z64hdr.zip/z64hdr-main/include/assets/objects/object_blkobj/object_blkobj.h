#ifndef OBJECT_BLKOBJ_H
#define OBJECT_BLKOBJ_H 1

extern Vtx object_blkobjVtx_000000[];
extern Gfx gIllusionRoomNormalDL[];
extern Vtx object_blkobjVtx_001F30[];
extern Gfx gIllusionRoomIllusionDL[];
extern CamData gIllusionRoomColCamDataList[];
extern SurfaceType gIllusionRoomColSurfaceType[];
extern CollisionPoly gIllusionRoomColPolygons[];
extern Vec3s gIllusionRoomColVertices[];
extern CollisionHeader gIllusionRoomCol;
extern Vtx object_blkobjVtx_007590[];
extern Gfx gIllusionRoomTreeDL[];
extern u64 object_blkobjTex_008090[];
extern u64 object_blkobjTex_008890[];
extern u64 object_blkobjTex_009090[];
extern u64 object_blkobjTex_009890[];
extern u64 object_blkobjTex_00A090[];
extern u64 object_blkobjTex_00A890[];
extern u64 object_blkobjTex_00B090[];
extern u64 object_blkobjTex_00B890[];
extern u64 object_blkobjTex_00C090[];
extern u64 object_blkobjTex_00C890[];
extern u64 object_blkobjTex_00D090[];
extern u64 object_blkobjTex_00D890[];
extern u64 object_blkobjTex_00E090[];
extern u64 object_blkobjTex_00E890[];
extern u64 object_blkobjTex_00F890[];
extern u64 object_blkobjTex_010090[];
extern u64 object_blkobjTex_010890[];
extern u64 object_blkobjTex_011090[];
extern u64 object_blkobjTex_011890[];
extern u64 object_blkobjTex_012090[];
extern u64 object_blkobjTex_012890[];
extern u64 object_blkobjTex_013090[];

#endif

#ifndef OBJECT_OE8_H
#define OBJECT_OE8_H 1

extern Vtx object_oE8Vtx_000000[];
extern Gfx object_oE8_DL_000CA0[];
extern u64 object_oE8_TLUT_001248[];
extern u64 object_oE8_Tex_001448[];
extern u8 object_oE8_Blob_001848[];
extern u64 object_oE8_TLUT_002048[];
extern u64 object_oE8_Tex_002248[];
extern u64 object_oE8_Tex_002288[];
extern u64 object_oE8_Tex_002388[];
extern u64 object_oE8_Tex_002788[];
extern u64 object_oE8_Tex_002B88[];
extern u64 object_oE8_Tex_002BC8[];

#endif

#ifndef OBJECT_GI_LONGSWORD_H
#define OBJECT_GI_LONGSWORD_H 1

extern Vtx object_gi_longswordVtx_000000[];
extern Gfx gGiBiggoronSwordDL[];

#endif

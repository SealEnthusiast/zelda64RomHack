#ifndef OBJECT_SPOT05_OBJECTS_H
#define OBJECT_SPOT05_OBJECTS_H 1

extern u64 object_spot05_objects_Tex_000000[];
extern Vtx object_spot05_objectsVtx_000800[];
extern Gfx object_spot05_objects_DL_000840[];
extern CamData object_spot05_objects_Col_000918CamDataList[];
extern SurfaceType object_spot05_objects_Col_000918SurfaceType[];
extern CollisionPoly object_spot05_objects_Col_000918Polygons[];
extern Vec3s object_spot05_objects_Col_000918Vertices[];
extern CollisionHeader object_spot05_objects_Col_000918;
extern u64 object_spot05_objects_Tex_000950[];
extern Vtx object_spot05_objectsVtx_001150[];
extern Gfx object_spot05_objects_DL_001190[];
extern CamData object_spot05_objects_Col_0012C0CamDataList[];
extern SurfaceType object_spot05_objects_Col_0012C0SurfaceType[];
extern CollisionPoly object_spot05_objects_Col_0012C0Polygons[];
extern Vec3s object_spot05_objects_Col_0012C0Vertices[];
extern CollisionHeader object_spot05_objects_Col_0012C0;

#endif

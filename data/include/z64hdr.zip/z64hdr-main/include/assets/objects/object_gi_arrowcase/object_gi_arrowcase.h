#ifndef OBJECT_GI_ARROWCASE_H
#define OBJECT_GI_ARROWCASE_H 1

extern Vtx object_gi_arrowcaseVtx_000000[];
extern Gfx gGiQuiver30InnerColorDL[];
extern Gfx gGiQuiver40InnerColorDL[];
extern Gfx gGiQuiver50InnerColorDL[];
extern Gfx gGiQuiver30OuterColorDL[];
extern Gfx gGiQuiver40OuterColorDL[];
extern Gfx gGiQuiver50OuterColorDL[];
extern Gfx gGiQuiverInnerDL[];
extern Gfx gGiQuiverOuterDL[];

#endif

#ifndef OBJECT_SIOFUKI_H
#define OBJECT_SIOFUKI_H 1

extern u64 object_siofuki_Tex_000000[];
extern Vtx object_siofukiVtx_000800[];
extern Gfx object_siofuki_DL_000B70[];
extern CamData object_siofuki_Col_000D78CamDataList[];
extern SurfaceType object_siofuki_Col_000D78SurfaceType[];
extern CollisionPoly object_siofuki_Col_000D78Polygons[];
extern Vec3s object_siofuki_Col_000D78Vertices[];
extern CollisionHeader object_siofuki_Col_000D78;

#endif

#ifndef OBJECT_TSUBO_H
#define OBJECT_TSUBO_H 1

extern u64 object_tsubo_Tex_000000[];
extern u64 object_tsubo_Tex_001000[];
extern u64 object_tsubo_Tex_001200[];
extern Vtx object_tsuboVtx_001400[];
extern Gfx object_tsubo_DL_0017C0[];
extern Vtx object_tsuboVtx_001930[];
extern Gfx object_tsubo_DL_001960[];

#endif

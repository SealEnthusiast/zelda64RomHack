#ifndef OBJECT_SPOT01_OBJECTS2_H
#define OBJECT_SPOT01_OBJECTS2_H 1

extern u8 object_spot01_objects2_Blob_000000[];

#endif

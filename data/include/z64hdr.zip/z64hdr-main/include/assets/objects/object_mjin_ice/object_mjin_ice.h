#ifndef OBJECT_MJIN_ICE_H
#define OBJECT_MJIN_ICE_H 1

extern u64 gWaterMedallionPlatformTex[];

#endif

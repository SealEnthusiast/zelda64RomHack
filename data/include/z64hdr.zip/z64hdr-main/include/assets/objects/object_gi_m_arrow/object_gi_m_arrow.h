#ifndef OBJECT_GI_M_ARROW_H
#define OBJECT_GI_M_ARROW_H 1

extern Vtx object_gi_m_arrowVtx_000000[];
extern Gfx gGiMagicArrowDL[];
extern Gfx gGiFireArrowColorDL[];
extern Gfx gGiIceArrowColorDL[];
extern Gfx gGiLightArrowColorDL[];
extern Gfx gGiArrowMagicDL[];

#endif

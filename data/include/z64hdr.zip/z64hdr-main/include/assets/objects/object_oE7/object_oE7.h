#ifndef OBJECT_OE7_H
#define OBJECT_OE7_H 1

extern Vtx object_oE7Vtx_000000[];
extern Gfx object_oE7_DL_0006B0[];
extern u64 object_oE7_TLUT_000B18[];
extern u64 object_oE7_Tex_000D18[];
extern u64 object_oE7_Tex_001118[];
extern u64 object_oE7_Tex_001158[];
extern u64 object_oE7_TLUT_001258[];
extern u64 object_oE7_Tex_001458[];
extern u8 object_oE7_Blob_001858[];
extern u64 object_oE7_Tex_002058[];
extern u64 object_oE7_Tex_002858[];

#endif

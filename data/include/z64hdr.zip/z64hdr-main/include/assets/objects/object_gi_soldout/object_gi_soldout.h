#ifndef OBJECT_GI_SOLDOUT_H
#define OBJECT_GI_SOLDOUT_H 1

extern u64 object_gi_soldoutTex_000000[];
extern Vtx object_gi_soldoutVtx_000400[];
extern Gfx gGiSoldOutDL[];

#endif

#ifndef OBJECT_BBA_H
#define OBJECT_BBA_H 1

extern StandardLimb object_bba_Limb_000000;
extern StandardLimb object_bba_Limb_00000C;
extern StandardLimb object_bba_Limb_000018;
extern StandardLimb object_bba_Limb_000024;
extern StandardLimb object_bba_Limb_000030;
extern StandardLimb object_bba_Limb_00003C;
extern StandardLimb object_bba_Limb_000048;
extern StandardLimb object_bba_Limb_000054;
extern StandardLimb object_bba_Limb_000060;
extern StandardLimb object_bba_Limb_00006C;
extern StandardLimb object_bba_Limb_000078;
extern StandardLimb object_bba_Limb_000084;
extern StandardLimb object_bba_Limb_000090;
extern StandardLimb object_bba_Limb_00009C;
extern StandardLimb object_bba_Limb_0000A8;
extern void* object_bba_Skel_0000F0Limbs[];
extern FlexSkeletonHeader object_bba_Skel_0000F0;
extern u64 object_bba_TLUT_000108[];
extern u64 object_bba_Tex_000308[];
extern u64 object_bba_Tex_000348[];
extern u64 object_bba_Tex_000388[];
extern u64 object_bba_Tex_000488[];
extern u64 object_bba_Tex_0004C8[];
extern u64 object_bba_Tex_000CC8[];
extern u64 object_bba_Tex_000DC8[];
extern u64 object_bba_Tex_000E08[];
extern u64 object_bba_Tex_000F08[];
extern Vtx object_bbaVtx_001008[];
extern Gfx object_bba_DL_002948[];
extern Gfx object_bba_DL_003298[];
extern Gfx object_bba_DL_0033A8[];
extern Gfx object_bba_DL_0034C8[];
extern Gfx object_bba_DL_0035F0[];
extern Gfx object_bba_DL_003700[];
extern Gfx object_bba_DL_003820[];
extern Gfx object_bba_DL_003948[];
extern Gfx object_bba_DL_003C80[];
extern Gfx object_bba_DL_003D50[];
extern Gfx object_bba_DL_003E20[];
extern Gfx object_bba_DL_003EF0[];
extern Gfx object_bba_DL_003FC0[];
extern Gfx object_bba_DL_004090[];
extern Gfx object_bba_DL_004160[];

#endif

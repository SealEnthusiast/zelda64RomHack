#ifndef OBJECT_GI_PACHINKO_H
#define OBJECT_GI_PACHINKO_H 1

extern Vtx object_gi_pachinkoVtx_000000[];
extern Gfx gGiSlingshotDL[];

#endif

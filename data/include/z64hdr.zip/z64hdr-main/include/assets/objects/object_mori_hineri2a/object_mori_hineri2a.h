#ifndef OBJECT_MORI_HINERI2A_H
#define OBJECT_MORI_HINERI2A_H 1

extern Vtx object_mori_hineri2aVtx_000000[];
extern Gfx object_mori_hineri2a_DL_002B70[];
extern CamData object_mori_hineri2a_Col_006078CamDataList[];
extern SurfaceType object_mori_hineri2a_Col_006078SurfaceType[];
extern CollisionPoly object_mori_hineri2a_Col_006078Polygons[];
extern Vec3s object_mori_hineri2a_Col_006078Vertices[];
extern CollisionHeader object_mori_hineri2a_Col_006078;

#endif

#ifndef OBJECT_WOOD02_H
#define OBJECT_WOOD02_H 1

extern Vtx object_wood02Vtx_000000[];
extern Gfx object_wood02_DL_000090[];
extern Vtx object_wood02Vtx_000130[];
extern Gfx object_wood02_DL_000160[];
extern Vtx object_wood02Vtx_0001F0[];
extern Gfx object_wood02_DL_000340[];
extern Vtx object_wood02Vtx_000410[];
extern Gfx object_wood02_DL_000440[];
extern u64 object_wood02_Tex_0004D0[];
extern Vtx object_wood02Vtx_0006D0[];
extern Gfx object_wood02_DL_000700[];
extern u64 object_wood02_Tex_000790[];
extern u64 object_wood02_Tex_000F90[];
extern u64 object_wood02_Tex_001790[];
extern u64 object_wood02_Tex_002790[];
extern u64 object_wood02_Tex_002F90[];
extern u64 object_wood02_Tex_003790[];
extern u64 object_wood02_Tex_004790[];
extern u64 object_wood02_Tex_004F90[];
extern u64 object_wood02_Tex_005F90[];
extern u64 object_wood02_Tex_006790[];
extern u64 object_wood02_Tex_006F90[];
extern Vtx object_wood02Vtx_007790[];
extern Gfx object_wood02_DL_0078D0[];
extern Gfx object_wood02_DL_007968[];
extern u8 object_wood02_Blob_007A00[];
extern Vtx object_wood02Vtx_007AA0[];
extern Gfx object_wood02_DL_007AD0[];
extern Vtx object_wood02Vtx_007B60[];
extern Gfx object_wood02_DL_007CA0[];
extern Gfx object_wood02_DL_007D38[];
extern Vtx object_wood02Vtx_007DF0[];
extern Gfx object_wood02_DL_007E20[];
extern Vtx object_wood02Vtx_007EB0[];
extern Gfx object_wood02_DL_0080D0[];
extern Gfx object_wood02_DL_0081A8[];
extern Vtx object_wood02Vtx_008240[];
extern Gfx object_wood02_DL_0082B0[];
extern Vtx object_wood02Vtx_008320[];
extern Gfx object_wood02_DL_008350[];
extern Gfx object_wood02_DL_0083E0[];
extern Gfx object_wood02_DL_0085C0[];
extern Vtx object_wood02Vtx_0085D0[];

#endif

#ifndef OBJECT_GI_MILK_H
#define OBJECT_GI_MILK_H 1

extern u64 object_gi_milkTex_000000[];
extern Vtx object_gi_milkVtx_0006C0[];
extern Gfx gGiMilkBottleContentsDL[];
extern Gfx gGiMilkBottleDL[];

#endif

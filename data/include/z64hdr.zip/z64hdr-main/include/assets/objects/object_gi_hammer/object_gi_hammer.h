#ifndef OBJECT_GI_HAMMER_H
#define OBJECT_GI_HAMMER_H 1

extern Vtx object_gi_hammerVtx_000000[];
extern Gfx gGiHammerDL[];

#endif

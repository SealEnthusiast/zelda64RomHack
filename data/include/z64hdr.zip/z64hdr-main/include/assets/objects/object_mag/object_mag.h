#ifndef OBJECT_MAG_H
#define OBJECT_MAG_H 1

extern u64 gTitleZeldaShieldLogoMQTex[];
extern u64 gTitleCopyright19982002Tex[];
extern u64 gTitleCopyright19982003Tex[];
extern u64 gTitleMasterQuestSubtitleTex[];
extern u64 gTitleUraLogoTex[];
extern u64 gTitleDiskTex[];
extern u64 gTitleEffectMask00Tex[];
extern u64 gTitleEffectMask01Tex[];
extern u64 gTitleEffectMask02Tex[];
extern u64 gTitleEffectMask10Tex[];
extern u64 gTitleEffectMask11Tex[];
extern u64 gTitleEffectMask12Tex[];
extern u64 gTitleEffectMask20Tex[];
extern u64 gTitleEffectMask21Tex[];
extern u64 gTitleEffectMask22Tex[];
extern u64 gTitleFlameEffectTex[];
extern u64 gTitleTheLegendOfTextTex[];
extern u64 gTitleOcarinaOfTimeTMTextTex[];
extern u64 gTitleTitleJPNTex[];

#endif

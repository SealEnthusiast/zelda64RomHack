#ifndef OBJECT_NWC_H
#define OBJECT_NWC_H 1

extern u64 gCuccoChickBodyTex[];
extern Vtx object_nwcVtx_000800[];
extern Gfx gCuccoChickSetupBodyDL[];
extern Gfx gCuccoChickBodyDL[];
extern u64 gCuccoChickEyeTex[];
extern u64 gCuccoChickBeakTex[];
extern Vtx object_nwcVtx_000B00[];
extern Gfx gCuccoChickSetupEyeDL[];
extern Gfx gCuccoChickEyesDL[];
extern Gfx gCuccoChickSetupBeakDL[];
extern Gfx gCuccoChickBeakDL[];
extern Gfx gCuccoChickSetupShadowDL[];
extern Gfx gCuccoChickShadowDL[];
extern Vtx object_nwcVtx_000D68[];

#endif

#ifndef OBJECT_GI_COMPASS_H
#define OBJECT_GI_COMPASS_H 1

extern Vtx object_gi_compassVtx_000000[];
extern Gfx gGiCompassDL[];
extern Gfx gGiCompassGlassDL[];

#endif

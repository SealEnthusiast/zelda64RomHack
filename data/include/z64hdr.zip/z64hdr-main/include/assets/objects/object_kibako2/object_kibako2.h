#ifndef OBJECT_KIBAKO2_H
#define OBJECT_KIBAKO2_H 1

extern u64 gLargeCrate1TLUT[];
extern u64 gLargeCrateTex[];
extern u64 gLargeCrateFragment1Tex[];
extern Vtx object_kibako2Vtx_000820[];
extern Gfx gLargeCrateDL[];
extern CamData gLargeCrateColCamDataList[];
extern SurfaceType gLargeCrateColSurfaceType[];
extern CollisionPoly gLargeCrateColPolygons[];
extern Vec3s gLargeCrateColVertices[];
extern CollisionHeader gLargeCrateCol;
extern u64 gLargeCrate2TLUT[];
extern u64 gLargeCrateFragment2Tex[];
extern Vtx object_kibako2Vtx_000FC0[];
extern Gfx gLargeCrateFragmentDL[];

#endif

#ifndef OBJECT_WARP2_H
#define OBJECT_WARP2_H 1

extern u8 gWarp2Blob_000000[];

#endif

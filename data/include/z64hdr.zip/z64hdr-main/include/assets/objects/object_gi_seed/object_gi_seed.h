#ifndef OBJECT_GI_SEED_H
#define OBJECT_GI_SEED_H 1

extern Vtx object_gi_seedVtx_000000[];
extern Gfx gGiSeedDL[];

#endif

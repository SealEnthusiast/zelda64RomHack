#ifndef OBJECT_OE11_H
#define OBJECT_OE11_H 1

extern Vtx object_oE11Vtx_000000[];
extern Gfx object_oE11_DL_0009F0[];
extern u64 object_oE11_TLUT_000F70[];
extern u64 object_oE11_Tex_001170[];
extern u8 object_oE11_Blob_001570[];
extern u64 object_oE11_TLUT_001D70[];
extern u64 object_oE11_Tex_001F70[];
extern u64 object_oE11_Tex_001FB0[];
extern u64 object_oE11_Tex_0020B0[];
extern u64 object_oE11_Tex_0021B0[];
extern u64 object_oE11_Tex_0029B0[];
extern u64 object_oE11_Tex_0031B0[];

#endif

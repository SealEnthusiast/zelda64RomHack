#ifndef OBJECT_OE10_H
#define OBJECT_OE10_H 1

extern Vtx object_oE10Vtx_000000[];
extern Gfx object_oE10_DL_000720[];
extern u64 object_oE10_TLUT_000C10[];
extern u64 object_oE10_Tex_000E10[];
extern u64 object_oE10_Tex_000E50[];
extern u64 object_oE10_Tex_000F50[];
extern u64 object_oE10_TLUT_000F90[];
extern u64 object_oE10_Tex_001190[];
extern u64 object_oE10_Tex_001590[];
extern u64 object_oE10_Tex_001D90[];
extern u64 object_oE10_Tex_001DD0[];
extern u64 object_oE10_Tex_0021D0[];

#endif

#ifndef OBJECT_O_ANIME_H
#define OBJECT_O_ANIME_H 1

extern s16 object_o_anime_Anim_000A1CFrameData[];
extern JointIndex object_o_anime_Anim_000A1CJointIndices[];
extern AnimationHeader object_o_anime_Anim_000A1C;
extern s16 object_o_anime_Anim_000E78FrameData[];
extern JointIndex object_o_anime_Anim_000E78JointIndices[];
extern AnimationHeader object_o_anime_Anim_000E78;
extern s16 object_o_anime_Anim_001300FrameData[];
extern JointIndex object_o_anime_Anim_001300JointIndices[];
extern AnimationHeader object_o_anime_Anim_001300;
extern s16 object_o_anime_Anim_0017B4FrameData[];
extern JointIndex object_o_anime_Anim_0017B4JointIndices[];
extern AnimationHeader object_o_anime_Anim_0017B4;
extern s16 object_o_anime_Anim_0018F0FrameData[];
extern JointIndex object_o_anime_Anim_0018F0JointIndices[];
extern AnimationHeader object_o_anime_Anim_0018F0;
extern s16 object_o_anime_Anim_001E80FrameData[];
extern JointIndex object_o_anime_Anim_001E80JointIndices[];
extern AnimationHeader object_o_anime_Anim_001E80;
extern s16 object_o_anime_Anim_00213CFrameData[];
extern JointIndex object_o_anime_Anim_00213CJointIndices[];
extern AnimationHeader object_o_anime_Anim_00213C;

#endif

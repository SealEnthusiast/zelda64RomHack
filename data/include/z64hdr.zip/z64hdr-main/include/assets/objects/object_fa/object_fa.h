#ifndef OBJECT_FA_H
#define OBJECT_FA_H 1

extern u64 gFaTLUT[];
extern u64 gFaSkinTex[];
extern u64 gFaEyeOpenTex[];
extern u64 gFaMouthTex[];
extern u64 gFaHair1Tex[];
extern u64 gFaEarTex[];
extern u64 gFaHair2Tex[];
extern u64 gFaHeadbandTex[];
extern u64 gFaEyeHalfTex[];
extern u64 gFaEyeClosedTex[];
extern Vtx object_faVtx_001540[];
extern Gfx gFaDL[];

#endif

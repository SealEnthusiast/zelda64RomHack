#ifndef OBJECT_TP_H
#define OBJECT_TP_H 1

extern Gfx gTailpasaranTailSegmentDL[];
extern Vtx object_tpVtx_000070[];
extern Gfx gTailpasaranHeadClawDL[];
extern Gfx gTailpasaranHeadMouthpartsDL[];
extern Gfx gTailpasaranHeadDL[];
extern u64 gTailpasaranHeadRearTex[];
extern u64 gTailpasaranHeadClawBaseTex[];
extern u64 gTailpasaranHeadClawTex[];
extern u64 gTailpasaranTailSegmentTex[];
extern u64 gTailpasaranHeadMouthpartsTex[];

#endif

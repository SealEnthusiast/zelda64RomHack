#ifndef OBJECT_NY_H
#define OBJECT_NY_H 1

extern u64 gEnNyRockBodyTex[];
extern u64 gEnNySpikeTex[];
extern u64 gEnNyMetalBodyTex[];
extern Vtx object_nyVtx_001200[];
extern Gfx gEnNyRockBodyDL[];
extern Gfx gEnNyMetalBodyDL[];
extern Gfx gEnNySpikeDL[];

#endif

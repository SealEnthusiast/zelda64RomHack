#ifndef OBJECT_TRIFORCE_SPOT_H
#define OBJECT_TRIFORCE_SPOT_H 1

extern Vtx gTriforceVtx[];
extern Vtx object_triforce_spotVtx_000200[];
extern Gfx gTriforceDL[];
extern Gfx gTriforceLightColumnDL[];
extern u64 gTriforceTex[];
extern u64 gTriforceColumnSide1Tex[];
extern u64 gTriforceColumnSide2Tex[];

#endif

#ifndef OBJECT_GI_EGG_H
#define OBJECT_GI_EGG_H 1

extern Vtx object_gi_eggVtx_000000[];
extern Gfx gGiEggMaterialDL[];
extern Gfx gGiEggDL[];

#endif

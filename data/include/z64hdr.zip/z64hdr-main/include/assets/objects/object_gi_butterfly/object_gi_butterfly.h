#ifndef OBJECT_GI_BUTTERFLY_H
#define OBJECT_GI_BUTTERFLY_H 1

extern u64 object_gi_butterflyTex_000000[];
extern Vtx object_gi_butterflyVtx_000240[];
extern Gfx gGiButterflyContainerDL[];
extern Gfx gGiButterflyGlassDL[];

#endif

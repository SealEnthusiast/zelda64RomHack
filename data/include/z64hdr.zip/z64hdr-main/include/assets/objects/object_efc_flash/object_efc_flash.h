#ifndef OBJECT_EFC_FLASH_H
#define OBJECT_EFC_FLASH_H 1

extern u8 gEfcFlashBlob_000000[];

#endif

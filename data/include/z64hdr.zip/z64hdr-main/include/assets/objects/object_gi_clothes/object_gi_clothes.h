#ifndef OBJECT_GI_CLOTHES_H
#define OBJECT_GI_CLOTHES_H 1

extern u64 object_gi_clothesTex_000000[];
extern Vtx object_gi_clothesVtx_000800[];
extern Gfx gGiGoronCollarColorDL[];
extern Gfx gGiZoraCollarColorDL[];
extern Gfx gGiGoronTunicColorDL[];
extern Gfx gGiZoraTunicColorDL[];
extern Gfx gGiTunicCollarDL[];
extern Gfx gGiTunicDL[];

#endif

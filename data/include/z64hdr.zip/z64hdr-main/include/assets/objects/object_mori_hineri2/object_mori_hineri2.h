#ifndef OBJECT_MORI_HINERI2_H
#define OBJECT_MORI_HINERI2_H 1

extern Vtx object_mori_hineri2Vtx_000000[];
extern Gfx object_mori_hineri2_DL_0020F0[];
extern CamData object_mori_hineri2_Col_0043D0CamDataList[];
extern SurfaceType object_mori_hineri2_Col_0043D0SurfaceType[];
extern CollisionPoly object_mori_hineri2_Col_0043D0Polygons[];
extern Vec3s object_mori_hineri2_Col_0043D0Vertices[];
extern CollisionHeader object_mori_hineri2_Col_0043D0;

#endif

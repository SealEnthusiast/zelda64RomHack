#ifndef OBJECT_OE12_H
#define OBJECT_OE12_H 1

extern Vtx object_oE12Vtx_000000[];
extern Gfx object_oE12_DL_001020[];
extern u64 object_oE12_TLUT_001600[];
extern u64 object_oE12_Tex_001800[];
extern u8 object_oE12_Blob_001C00[];
extern u64 object_oE12_Tex_002400[];
extern u64 object_oE12_Tex_002480[];
extern u64 object_oE12_Tex_002880[];
extern u64 object_oE12_Tex_002980[];
extern u64 object_oE12_Tex_002B80[];
extern u64 object_oE12_Tex_003380[];
extern u64 object_oE12_Tex_003780[];

#endif

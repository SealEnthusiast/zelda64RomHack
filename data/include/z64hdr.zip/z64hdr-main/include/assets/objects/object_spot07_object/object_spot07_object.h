#ifndef OBJECT_SPOT07_OBJECT_H
#define OBJECT_SPOT07_OBJECT_H 1

extern Vtx object_spot07_objectVtx_000000[];
extern Gfx object_spot07_object_DL_000460[];
extern Vtx object_spot07_objectVtx_000700[];
extern Gfx object_spot07_object_DL_000BE0[];
extern u64 object_spot07_object_TLUT_000EC0[];
extern u64 object_spot07_object_Tex_000EE0[];
extern Vtx object_spot07_objectVtx_0016E0[];
extern Gfx object_spot07_object_DL_001CF0[];
extern Gfx object_spot07_object_DL_001F68[];
extern CamData object_spot07_object_Col_002590CamDataList[];
extern SurfaceType object_spot07_object_Col_002590SurfaceType[];
extern CollisionPoly object_spot07_object_Col_002590Polygons[];
extern Vec3s object_spot07_object_Col_002590Vertices[];
extern CollisionHeader object_spot07_object_Col_002590;
extern u64 object_spot07_object_TLUT_0025C0[];
extern u64 object_spot07_object_Tex_0025E0[];
extern Vtx object_spot07_objectVtx_002DE0[];
extern Gfx object_spot07_object_DL_003210[];
extern Gfx object_spot07_object_DL_0032D8[];
extern CamData object_spot07_object_Col_0038FCCamDataList[];
extern SurfaceType object_spot07_object_Col_0038FCSurfaceType[];
extern CollisionPoly object_spot07_object_Col_0038FCPolygons[];
extern Vec3s object_spot07_object_Col_0038FCVertices[];
extern CollisionHeader object_spot07_object_Col_0038FC;
extern u64 object_spot07_object_Tex_003930[];
extern u64 object_spot07_object_Tex_004130[];
extern u64 object_spot07_object_Tex_004930[];
extern u64 object_spot07_object_Tex_005130[];
extern u64 object_spot07_object_Tex_005530[];
extern u64 object_spot07_object_Tex_005D30[];
extern u64 object_spot07_object_Tex_006530[];

#endif

#ifndef OBJECT_OA3_H
#define OBJECT_OA3_H 1

extern u8 object_oA3_Blob_00000000[];
extern Gfx object_oA3_DL_00000008[];
extern Vtx object_oA3Vtx_000428[];
extern u64 object_oA3_Tex_000012F0[];
extern u64 object_oA3_Tex_00001AF0[];
extern u64 object_oA3_Tex_00001CF0[];
extern u64 object_oA3_Tex_00001EF0[];
extern u64 object_oA3_Tex_000020F0[];

#endif

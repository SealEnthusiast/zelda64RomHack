#ifndef OBJECT_EFC_FIRE_BALL_H
#define OBJECT_EFC_FIRE_BALL_H 1

extern Vtx object_efc_fire_ballVtx_000000[];
extern Gfx gCreationFireBallDL[];
extern u64 gCreationFireBallMaskTex[];
extern u64 gCreationFireBallFlameEffectTex[];

#endif

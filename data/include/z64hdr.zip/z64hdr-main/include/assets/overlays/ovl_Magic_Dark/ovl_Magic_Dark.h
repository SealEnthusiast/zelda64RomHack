#ifndef OVL_MAGIC_DARK_H
#define OVL_MAGIC_DARK_H 1


#endif

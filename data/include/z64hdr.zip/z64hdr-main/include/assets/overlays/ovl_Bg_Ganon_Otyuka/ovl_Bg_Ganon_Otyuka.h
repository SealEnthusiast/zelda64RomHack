#ifndef OVL_BG_GANON_OTYUKA_H
#define OVL_BG_GANON_OTYUKA_H 1


#endif

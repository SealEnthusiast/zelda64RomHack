#ifndef OVL_MAGIC_FIRE_H
#define OVL_MAGIC_FIRE_H 1


#endif

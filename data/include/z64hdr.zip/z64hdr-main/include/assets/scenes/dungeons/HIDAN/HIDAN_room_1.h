#ifndef HIDAN_ROOM_1_H
#define HIDAN_ROOM_1_H 1

extern SceneCmd HIDAN_room_1Commands[];
extern s16 HIDAN_room_1ObjectList_000040[];
extern ActorEntry HIDAN_room_1ActorList_00004C[];
extern PolygonType2 HIDAN_room_1PolygonType2_000190;
extern PolygonDlist2 HIDAN_room_1PolygonDlist2_00019C[7];
extern s32 HIDAN_room_1_terminatorMaybe_00020C;
extern Vtx HIDAN_room_1Vtx_000210[];
extern Gfx HIDAN_room_1DL_0002D0[];
extern Vtx HIDAN_room_1Vtx_0003C8[];
extern Gfx HIDAN_room_1DL_000DC8[];
extern Vtx HIDAN_room_1Vtx_001480[];
extern Gfx HIDAN_room_1DL_002500[];
extern Vtx HIDAN_room_1Vtx_003368[];
extern Gfx HIDAN_room_1DL_004068[];
extern Vtx HIDAN_room_1Vtx_004DB0[];
extern Gfx HIDAN_room_1DL_0057B0[];
extern Vtx HIDAN_room_1Vtx_005E28[];
extern Gfx HIDAN_room_1DL_006BF8[];
extern Vtx HIDAN_room_1Vtx_007688[];
extern Gfx HIDAN_room_1DL_008448[];
extern u64 HIDAN_room_1Tex_008730[];
extern u64 HIDAN_room_1Tex_008930[];
extern u64 HIDAN_room_1Tex_009130[];
extern u64 HIDAN_room_1Tex_009930[];
extern u64 HIDAN_room_1Tex_00A130[];
extern u64 HIDAN_room_1Tex_00A530[];
extern u64 HIDAN_room_1Tex_00B530[];
extern u64 HIDAN_room_1Tex_00BD30[];
extern u64 HIDAN_room_1Tex_00C130[];

#endif

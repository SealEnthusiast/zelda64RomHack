#ifndef BMORI1_ROOM_22_H
#define BMORI1_ROOM_22_H 1

extern SceneCmd Bmori1_room_22Commands[];
extern s16 Bmori1_room_22ObjectList_000038[];
extern PolygonType0 Bmori1_room_22PolygonType0_000050;
extern PolygonDlist Bmori1_room_22PolygonDlist_00005C[1];
extern s32 Bmori1_room_22_terminatorMaybe_000064;
extern Vtx Bmori1_room_22Vtx_000070[];
extern Gfx Bmori1_room_22DL_000390[];
extern Gfx Bmori1_room_22DL_0005D0[];
extern u64 Bmori1_room_22Tex_0005E0[];
extern u64 Bmori1_room_22Tex_0015E0[];

#endif

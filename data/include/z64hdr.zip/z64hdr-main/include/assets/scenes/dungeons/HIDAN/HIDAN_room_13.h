#ifndef HIDAN_ROOM_13_H
#define HIDAN_ROOM_13_H 1

extern SceneCmd HIDAN_room_13Commands[];
extern s16 HIDAN_room_13ObjectList_000040[];
extern ActorEntry HIDAN_room_13ActorList_000050[];
extern PolygonType2 HIDAN_room_13PolygonType2_000110;
extern PolygonDlist2 HIDAN_room_13PolygonDlist2_00011C[6];
extern s32 HIDAN_room_13_terminatorMaybe_00017C;
extern Vtx HIDAN_room_13Vtx_000180[];
extern Gfx HIDAN_room_13DL_001210[];
extern Vtx HIDAN_room_13Vtx_0024C8[];
extern Gfx HIDAN_room_13DL_0031F8[];
extern Vtx HIDAN_room_13Vtx_0040A8[];
extern Gfx HIDAN_room_13DL_005138[];
extern Vtx HIDAN_room_13Vtx_006498[];
extern Gfx HIDAN_room_13DL_007908[];
extern Vtx HIDAN_room_13Vtx_008B30[];
extern Gfx HIDAN_room_13DL_009160[];
extern Vtx HIDAN_room_13Vtx_009638[];
extern Gfx HIDAN_room_13DL_00A228[];
extern u64 HIDAN_room_13Tex_00A788[];
extern u64 HIDAN_room_13Tex_00AF88[];
extern u64 HIDAN_room_13Tex_00B388[];
extern u64 HIDAN_room_13Tex_00B788[];
extern u64 HIDAN_room_13Tex_00BB88[];
extern u64 HIDAN_room_13Tex_00C388[];

#endif

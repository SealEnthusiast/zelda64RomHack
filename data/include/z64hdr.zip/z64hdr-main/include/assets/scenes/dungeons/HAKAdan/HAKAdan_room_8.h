#ifndef HAKADAN_ROOM_8_H
#define HAKADAN_ROOM_8_H 1

extern SceneCmd HAKAdan_room_8Commands[];
extern s16 HAKAdan_room_8ObjectList_000040[];
extern ActorEntry HAKAdan_room_8ActorList_000050[];
extern PolygonType2 HAKAdan_room_8PolygonType2_0000D0;
extern PolygonDlist2 HAKAdan_room_8PolygonDlist2_0000DC[4];
extern s32 HAKAdan_room_8_terminatorMaybe_00011C;
extern Vtx HAKAdan_room_8Vtx_000120[];
extern Gfx HAKAdan_room_8DL_000E70[];
extern Vtx HAKAdan_room_8Vtx_0011C8[];
extern Gfx HAKAdan_room_8DL_001CE8[];
extern Vtx HAKAdan_room_8Vtx_001FE8[];
extern Gfx HAKAdan_room_8DL_002418[];
extern Vtx HAKAdan_room_8Vtx_0025E8[];
extern Gfx HAKAdan_room_8DL_002CC8[];
extern u64 HAKAdan_room_8Tex_003098[];
extern u64 HAKAdan_room_8Tex_003298[];
extern u64 HAKAdan_room_8Tex_004298[];
extern u64 HAKAdan_room_8Tex_004A98[];
extern u64 HAKAdan_room_8Tex_004C98[];

#endif

#ifndef HIDAN_ROOM_14_H
#define HIDAN_ROOM_14_H 1

extern SceneCmd HIDAN_room_14Commands[];
extern s16 HIDAN_room_14ObjectList_000040[];
extern ActorEntry HIDAN_room_14ActorList_000048[];
extern PolygonType2 HIDAN_room_14PolygonType2_0000A0;
extern PolygonDlist2 HIDAN_room_14PolygonDlist2_0000AC[1];
extern s32 HIDAN_room_14_terminatorMaybe_0000BC;
extern Vtx HIDAN_room_14Vtx_0000C0[];
extern Gfx HIDAN_room_14DL_001030[];
extern u64 HIDAN_room_14Tex_0019F8[];
extern u64 HIDAN_room_14Tex_001DF8[];

#endif

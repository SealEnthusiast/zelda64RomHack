#ifndef HAKADAN_ROOM_0_H
#define HAKADAN_ROOM_0_H 1

extern SceneCmd HAKAdan_room_0Commands[];
extern s16 HAKAdan_room_0ObjectList_000040[];
extern ActorEntry HAKAdan_room_0ActorList_000050[];
extern PolygonType2 HAKAdan_room_0PolygonType2_0001D0;
extern PolygonDlist2 HAKAdan_room_0PolygonDlist2_0001DC[6];
extern s32 HAKAdan_room_0_terminatorMaybe_00023C;
extern Vtx HAKAdan_room_0Vtx_000240[];
extern Gfx HAKAdan_room_0DL_000D00[];
extern Vtx HAKAdan_room_0Vtx_000FA8[];
extern Gfx HAKAdan_room_0DL_002768[];
extern Vtx HAKAdan_room_0Vtx_003840[];
extern Gfx HAKAdan_room_0DL_0045C0[];
extern Vtx HAKAdan_room_0Vtx_004890[];
extern Gfx HAKAdan_room_0DL_005FF0[];
extern Vtx HAKAdan_room_0Vtx_0070C8[];
extern Gfx HAKAdan_room_0DL_007EC8[];
extern u64 HAKAdan_room_0Tex_008230[];
extern u64 HAKAdan_room_0Tex_009230[];
extern u64 HAKAdan_room_0Tex_00A230[];
extern Vtx HAKAdan_room_0Vtx_00AA30[];
extern Gfx HAKAdan_room_0DL_00AC40[];
extern u64 HAKAdan_room_0Tex_00AD48[];

#endif

#ifndef HAKADANCH_ROOM_3_H
#define HAKADANCH_ROOM_3_H 1

extern SceneCmd HAKAdanCH_room_3Commands[];
extern s16 HAKAdanCH_room_3ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_3ActorList_00005C[];
extern PolygonType2 HAKAdanCH_room_3PolygonType2_000120;
extern PolygonDlist2 HAKAdanCH_room_3PolygonDlist2_00012C[3];
extern s32 HAKAdanCH_room_3_terminatorMaybe_00015C;
extern Vtx HAKAdanCH_room_3Vtx_000160[];
extern Gfx HAKAdanCH_room_3DL_000D40[];
extern Vtx HAKAdanCH_room_3Vtx_001018[];
extern Gfx HAKAdanCH_room_3DL_001198[];
extern Vtx HAKAdanCH_room_3Vtx_0012B0[];
extern Gfx HAKAdanCH_room_3DL_0013A0[];
extern u64 HAKAdanCH_room_3Tex_0014C0[];

#endif

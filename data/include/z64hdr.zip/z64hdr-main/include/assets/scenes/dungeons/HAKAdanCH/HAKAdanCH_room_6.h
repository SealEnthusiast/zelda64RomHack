#ifndef HAKADANCH_ROOM_6_H
#define HAKADANCH_ROOM_6_H 1

extern SceneCmd HAKAdanCH_room_6Commands[];
extern s16 HAKAdanCH_room_6ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_6ActorList_000050[];
extern PolygonType2 HAKAdanCH_room_6PolygonType2_0000C0;
extern PolygonDlist2 HAKAdanCH_room_6PolygonDlist2_0000CC[2];
extern s32 HAKAdanCH_room_6_terminatorMaybe_0000EC;
extern Vtx HAKAdanCH_room_6Vtx_0000F0[];
extern Gfx HAKAdanCH_room_6DL_000410[];
extern Vtx HAKAdanCH_room_6Vtx_000570[];
extern Gfx HAKAdanCH_room_6DL_000C30[];
extern u64 HAKAdanCH_room_6Tex_000EA0[];
extern u64 HAKAdanCH_room_6Tex_0016A0[];
extern u64 HAKAdanCH_room_6Tex_0026A0[];

#endif

#ifndef HIDAN_ROOM_0_H
#define HIDAN_ROOM_0_H 1

extern SceneCmd HIDAN_room_0Commands[];
extern s16 HIDAN_room_0ObjectList_000040[];
extern ActorEntry HIDAN_room_0ActorList_000048[];
extern PolygonType2 HIDAN_room_0PolygonType2_000100;
extern PolygonDlist2 HIDAN_room_0PolygonDlist2_00010C[1];
extern s32 HIDAN_room_0_terminatorMaybe_00011C;
extern Vtx HIDAN_room_0Vtx_000120[];
extern Gfx HIDAN_room_0DL_002C50[];
extern u64 HIDAN_room_0Tex_004EF0[];
extern u64 HIDAN_room_0Tex_0052F0[];
extern u64 HIDAN_room_0Tex_0056F0[];
extern u64 HIDAN_room_0Tex_005AF0[];
extern u64 HIDAN_room_0Tex_005CF0[];
extern u64 HIDAN_room_0Tex_005EF0[];
extern u64 HIDAN_room_0Tex_0062F0[];

#endif

#ifndef HIDAN_ROOM_11_H
#define HIDAN_ROOM_11_H 1

extern SceneCmd HIDAN_room_11Commands[];
extern s16 HIDAN_room_11ObjectList_000040[];
extern ActorEntry HIDAN_room_11ActorList_000050[];
extern PolygonType2 HIDAN_room_11PolygonType2_000100;
extern PolygonDlist2 HIDAN_room_11PolygonDlist2_00010C[3];
extern s32 HIDAN_room_11_terminatorMaybe_00013C;
extern Vtx HIDAN_room_11Vtx_000140[];
extern Gfx HIDAN_room_11DL_0009E0[];
extern Vtx HIDAN_room_11Vtx_000E08[];
extern Gfx HIDAN_room_11DL_001908[];
extern Vtx HIDAN_room_11Vtx_002088[];
extern Gfx HIDAN_room_11DL_002628[];
extern u64 HIDAN_room_11Tex_0027D8[];
extern u64 HIDAN_room_11Tex_002FD8[];
extern u64 HIDAN_room_11Tex_0033D8[];

#endif

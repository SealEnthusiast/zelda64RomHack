#ifndef BMORI1_ROOM_16_H
#define BMORI1_ROOM_16_H 1

extern SceneCmd Bmori1_room_16Commands[];
extern s16 Bmori1_room_16ObjectList_000040[];
extern ActorEntry Bmori1_room_16ActorList_000050[];
extern PolygonType0 Bmori1_room_16PolygonType0_0000D0;
extern PolygonDlist Bmori1_room_16PolygonDlist_0000DC[1];
extern s32 Bmori1_room_16_terminatorMaybe_0000E4;
extern Vtx Bmori1_room_16Vtx_0000F0[];
extern Gfx Bmori1_room_16DL_001A60[];
extern Gfx Bmori1_room_16DL_002F88[];
extern u64 Bmori1_room_16Tex_002F98[];
extern u64 Bmori1_room_16Tex_003798[];
extern u64 Bmori1_room_16Tex_003F98[];
extern u64 Bmori1_room_16Tex_004398[];
extern u64 Bmori1_room_16Tex_004798[];

#endif

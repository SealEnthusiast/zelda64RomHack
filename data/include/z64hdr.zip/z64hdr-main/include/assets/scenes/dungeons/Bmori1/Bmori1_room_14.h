#ifndef BMORI1_ROOM_14_H
#define BMORI1_ROOM_14_H 1

extern SceneCmd Bmori1_room_14Commands[];
extern s16 Bmori1_room_14ObjectList_000040[];
extern ActorEntry Bmori1_room_14ActorList_000054[];
extern PolygonType0 Bmori1_room_14PolygonType0_000100;
extern PolygonDlist Bmori1_room_14PolygonDlist_00010C[1];
extern s32 Bmori1_room_14_terminatorMaybe_000114;
extern Vtx Bmori1_room_14Vtx_000120[];
extern Gfx Bmori1_room_14DL_001320[];
extern Vtx Bmori1_room_14Vtx_001DC8[];
extern Gfx Bmori1_room_14DL_002108[];
extern Vtx Bmori1_room_14Vtx_0023C0[];
extern Gfx Bmori1_room_14DL_0025E0[];
extern Vtx Bmori1_room_14Vtx_002718[];
extern Gfx Bmori1_room_14DL_002A58[];
extern Vtx Bmori1_room_14Vtx_002D58[];
extern Gfx Bmori1_room_14DL_002FD8[];
extern Vtx Bmori1_room_14Vtx_003150[];
extern Gfx Bmori1_room_14DL_003270[];
extern Vtx Bmori1_room_14Vtx_003360[];
extern Gfx Bmori1_room_14DL_003460[];
extern Gfx Bmori1_room_14DL_003520[];
extern u64 Bmori1_room_14Tex_003560[];
extern u64 Bmori1_room_14Tex_003960[];
extern u64 Bmori1_room_14Tex_004160[];
extern u64 Bmori1_room_14Tex_004960[];
extern u64 Bmori1_room_14Tex_004D60[];
extern Vtx Bmori1_room_14Vtx_005560[];
extern Gfx Bmori1_room_14DL_005670[];
extern Gfx Bmori1_room_14DL_005760[];
extern u64 Bmori1_room_14Tex_005770[];

#endif

#ifndef HAKADAN_ROOM_12_H
#define HAKADAN_ROOM_12_H 1

extern SceneCmd HAKAdan_room_12Commands[];
extern s16 HAKAdan_room_12ObjectList_000040[];
extern ActorEntry HAKAdan_room_12ActorList_000058[];
extern PolygonType2 HAKAdan_room_12PolygonType2_000120;
extern PolygonDlist2 HAKAdan_room_12PolygonDlist2_00012C[4];
extern s32 HAKAdan_room_12_terminatorMaybe_00016C;
extern Vtx HAKAdan_room_12Vtx_000170[];
extern Gfx HAKAdan_room_12DL_000CF0[];
extern Vtx HAKAdan_room_12Vtx_0011B0[];
extern Gfx HAKAdan_room_12DL_0014F0[];
extern Vtx HAKAdan_room_12Vtx_001660[];
extern Gfx HAKAdan_room_12DL_001C60[];
extern Vtx HAKAdan_room_12Vtx_001E48[];
extern Gfx HAKAdan_room_12DL_002A88[];
extern u64 HAKAdan_room_12Tex_003348[];
extern u64 HAKAdan_room_12Tex_003548[];
extern u64 HAKAdan_room_12Tex_003748[];
extern u64 HAKAdan_room_12Tex_003B48[];
extern u64 HAKAdan_room_12Tex_003D48[];
extern u64 HAKAdan_room_12Tex_004D48[];
extern u64 HAKAdan_room_12Tex_005548[];

#endif

#ifndef FIRE_BS_ROOM_1_H
#define FIRE_BS_ROOM_1_H 1

extern SceneCmd FIRE_bs_room_1Commands[];
extern s16 FIRE_bs_room_1ObjectList_000040[];
extern ActorEntry FIRE_bs_room_1ActorList_000050[];
extern PolygonType0 FIRE_bs_room_1PolygonType0_000070;
extern PolygonDlist FIRE_bs_room_1PolygonDlist_00007C[1];
extern s32 FIRE_bs_room_1_terminatorMaybe_000084;
extern Vtx FIRE_bs_room_1Vtx_000090[];
extern Gfx FIRE_bs_room_1DL_000BE0[];
extern Vtx FIRE_bs_room_1Vtx_0010E0[];
extern Gfx FIRE_bs_room_1DL_001460[];
extern Vtx FIRE_bs_room_1Vtx_0016A8[];
extern Gfx FIRE_bs_room_1DL_001A28[];
extern Vtx FIRE_bs_room_1Vtx_001C70[];
extern Gfx FIRE_bs_room_1DL_001FF0[];
extern Vtx FIRE_bs_room_1Vtx_002238[];
extern Gfx FIRE_bs_room_1DL_002338[];
extern Vtx FIRE_bs_room_1Vtx_002400[];
extern Gfx FIRE_bs_room_1DL_002600[];
extern Vtx FIRE_bs_room_1Vtx_0026F0[];
extern Gfx FIRE_bs_room_1DL_003070[];
extern Vtx FIRE_bs_room_1Vtx_003380[];
extern Gfx FIRE_bs_room_1DL_003480[];
extern Vtx FIRE_bs_room_1Vtx_003588[];
extern Gfx FIRE_bs_room_1DL_003698[];
extern Vtx FIRE_bs_room_1Vtx_0037A8[];
extern Gfx FIRE_bs_room_1DL_0045B8[];
extern Gfx FIRE_bs_room_1DL_004940[];
extern u64 FIRE_bs_room_1TLUT_004998[];
extern u64 FIRE_bs_room_1TLUT_0049B8[];
extern u64 FIRE_bs_room_1Tex_0049D8[];
extern u64 FIRE_bs_room_1Tex_004BD8[];
extern u64 FIRE_bs_room_1Tex_0053D8[];
extern u64 FIRE_bs_room_1Tex_005BD8[];
extern u64 FIRE_bs_room_1Tex_005FD8[];
extern u64 FIRE_bs_room_1Tex_0061D8[];
extern u64 FIRE_bs_room_1Tex_0065D8[];
extern u64 FIRE_bs_room_1Tex_006DD8[];

#endif

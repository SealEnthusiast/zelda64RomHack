#ifndef HIDAN_ROOM_19_H
#define HIDAN_ROOM_19_H 1

extern SceneCmd HIDAN_room_19Commands[];
extern s16 HIDAN_room_19ObjectList_000040[];
extern ActorEntry HIDAN_room_19ActorList_00004C[];
extern PolygonType2 HIDAN_room_19PolygonType2_000150;
extern PolygonDlist2 HIDAN_room_19PolygonDlist2_00015C[1];
extern s32 HIDAN_room_19_terminatorMaybe_00016C;
extern Vtx HIDAN_room_19Vtx_000170[];
extern Gfx HIDAN_room_19DL_001C00[];
extern u64 HIDAN_room_19Tex_002E28[];
extern u64 HIDAN_room_19Tex_003628[];
extern u64 HIDAN_room_19Tex_003A28[];
extern u64 HIDAN_room_19Tex_003E28[];
extern u64 HIDAN_room_19Tex_004028[];

#endif

#ifndef BMORI1_ROOM_12_H
#define BMORI1_ROOM_12_H 1

extern SceneCmd Bmori1_room_12Commands[];
extern s16 Bmori1_room_12ObjectList_000040[];
extern ActorEntry Bmori1_room_12ActorList_000054[];
extern PolygonType0 Bmori1_room_12PolygonType0_0000B0;
extern PolygonDlist Bmori1_room_12PolygonDlist_0000BC[1];
extern s32 Bmori1_room_12_terminatorMaybe_0000C4;
extern Vtx Bmori1_room_12Vtx_0000D0[];
extern Gfx Bmori1_room_12DL_001E80[];
extern Vtx Bmori1_room_12Vtx_003B68[];
extern Gfx Bmori1_room_12DL_0041E8[];
extern Gfx Bmori1_room_12DL_0049E8[];
extern u64 Bmori1_room_12Tex_004A00[];
extern u64 Bmori1_room_12Tex_004E00[];
extern u64 Bmori1_room_12Tex_005600[];
extern u64 Bmori1_room_12Tex_005E00[];
extern u64 Bmori1_room_12Tex_006600[];
extern u64 Bmori1_room_12Tex_006E00[];
extern u64 Bmori1_room_12Tex_007200[];
extern Vtx Bmori1_room_12Vtx_007A00[];
extern Gfx Bmori1_room_12DL_007B00[];
extern Gfx Bmori1_room_12DL_007BC8[];
extern u64 Bmori1_room_12Tex_007BD8[];

#endif

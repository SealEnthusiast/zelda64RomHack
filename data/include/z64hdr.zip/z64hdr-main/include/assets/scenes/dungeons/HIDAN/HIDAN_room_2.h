#ifndef HIDAN_ROOM_2_H
#define HIDAN_ROOM_2_H 1

extern SceneCmd HIDAN_room_2Commands[];
extern s16 HIDAN_room_2ObjectList_000040[];
extern ActorEntry HIDAN_room_2ActorList_000058[];
extern PolygonType2 HIDAN_room_2PolygonType2_000170;
extern PolygonDlist2 HIDAN_room_2PolygonDlist2_00017C[4];
extern s32 HIDAN_room_2_terminatorMaybe_0001BC;
extern Vtx HIDAN_room_2Vtx_0001C0[];
extern Gfx HIDAN_room_2DL_002A80[];
extern Vtx HIDAN_room_2Vtx_0054E0[];
extern Gfx HIDAN_room_2DL_005A80[];
extern Vtx HIDAN_room_2Vtx_005CF0[];
extern Gfx HIDAN_room_2DL_0079A0[];
extern Vtx HIDAN_room_2Vtx_0092D0[];
extern Gfx HIDAN_room_2DL_0094C0[];
extern u64 HIDAN_room_2Tex_009628[];
extern u64 HIDAN_room_2Tex_009828[];
extern u64 HIDAN_room_2Tex_00A028[];
extern u64 HIDAN_room_2Tex_00A828[];
extern u64 HIDAN_room_2Tex_00AC28[];
extern u64 HIDAN_room_2Tex_00BC28[];
extern u64 HIDAN_room_2Tex_00CC28[];
extern u64 HIDAN_room_2Tex_00CE28[];
extern u64 HIDAN_room_2Tex_00DE28[];
extern u64 HIDAN_room_2Tex_00E028[];
extern u64 HIDAN_room_2Tex_00E428[];
extern u64 HIDAN_room_2Tex_00EC28[];
extern u64 HIDAN_room_2Tex_00F028[];
extern u64 HIDAN_room_2Tex_00F828[];

#endif

#ifndef HAKADAN_ROOM_11_H
#define HAKADAN_ROOM_11_H 1

extern SceneCmd HAKAdan_room_11Commands[];
extern s16 HAKAdan_room_11ObjectList_000040[];
extern ActorEntry HAKAdan_room_11ActorList_000050[];
extern PolygonType2 HAKAdan_room_11PolygonType2_0001C0;
extern PolygonDlist2 HAKAdan_room_11PolygonDlist2_0001CC[6];
extern s32 HAKAdan_room_11_terminatorMaybe_00022C;
extern Vtx HAKAdan_room_11Vtx_000230[];
extern Gfx HAKAdan_room_11DL_0008B0[];
extern Vtx HAKAdan_room_11Vtx_000B90[];
extern Gfx HAKAdan_room_11DL_000F30[];
extern Vtx HAKAdan_room_11Vtx_0010D0[];
extern Gfx HAKAdan_room_11DL_0013D0[];
extern Vtx HAKAdan_room_11Vtx_001518[];
extern Gfx HAKAdan_room_11DL_001928[];
extern Vtx HAKAdan_room_11Vtx_001AA8[];
extern Gfx HAKAdan_room_11DL_001B78[];
extern Vtx HAKAdan_room_11Vtx_001C88[];
extern Gfx HAKAdan_room_11DL_001D58[];
extern u64 HAKAdan_room_11Tex_001E60[];
extern u64 HAKAdan_room_11Tex_002660[];
extern u64 HAKAdan_room_11Tex_002A60[];
extern u64 HAKAdan_room_11Tex_002C60[];
extern u64 HAKAdan_room_11Tex_003460[];
extern u64 HAKAdan_room_11Tex_003C60[];

#endif

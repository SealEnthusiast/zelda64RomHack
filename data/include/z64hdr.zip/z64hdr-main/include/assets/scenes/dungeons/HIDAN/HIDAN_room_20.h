#ifndef HIDAN_ROOM_20_H
#define HIDAN_ROOM_20_H 1

extern SceneCmd HIDAN_room_20Commands[];
extern s16 HIDAN_room_20ObjectList_000040[];
extern ActorEntry HIDAN_room_20ActorList_00004C[];
extern PolygonType2 HIDAN_room_20PolygonType2_0000B0;
extern PolygonDlist2 HIDAN_room_20PolygonDlist2_0000BC[1];
extern s32 HIDAN_room_20_terminatorMaybe_0000CC;
extern Vtx HIDAN_room_20Vtx_0000D0[];
extern Gfx HIDAN_room_20DL_001BE0[];
extern u64 HIDAN_room_20Tex_002D08[];
extern u64 HIDAN_room_20Tex_003508[];
extern u64 HIDAN_room_20Tex_003D08[];
extern u64 HIDAN_room_20Tex_004508[];
extern u64 HIDAN_room_20Tex_004D08[];
extern u64 HIDAN_room_20Tex_005508[];
extern u64 HIDAN_room_20Tex_005D08[];
extern u64 HIDAN_room_20Tex_006508[];

#endif

#ifndef HIDAN_ROOM_18_H
#define HIDAN_ROOM_18_H 1

extern SceneCmd HIDAN_room_18Commands[];
extern s16 HIDAN_room_18ObjectList_000040[];
extern ActorEntry HIDAN_room_18ActorList_000048[];
extern PolygonType2 HIDAN_room_18PolygonType2_000150;
extern PolygonDlist2 HIDAN_room_18PolygonDlist2_00015C[1];
extern s32 HIDAN_room_18_terminatorMaybe_00016C;
extern Vtx HIDAN_room_18Vtx_000170[];
extern Gfx HIDAN_room_18DL_001890[];
extern u64 HIDAN_room_18Tex_0027F8[];
extern u64 HIDAN_room_18Tex_002FF8[];
extern u64 HIDAN_room_18Tex_0033F8[];
extern u64 HIDAN_room_18Tex_0037F8[];
extern u64 HIDAN_room_18Tex_0039F8[];

#endif

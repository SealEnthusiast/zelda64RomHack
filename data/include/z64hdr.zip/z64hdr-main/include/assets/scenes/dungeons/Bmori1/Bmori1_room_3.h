#ifndef BMORI1_ROOM_3_H
#define BMORI1_ROOM_3_H 1

extern SceneCmd Bmori1_room_3Commands[];
extern s16 Bmori1_room_3ObjectList_000040[];
extern ActorEntry Bmori1_room_3ActorList_00004C[];
extern PolygonType0 Bmori1_room_3PolygonType0_000090;
extern PolygonDlist Bmori1_room_3PolygonDlist_00009C[1];
extern s32 Bmori1_room_3_terminatorMaybe_0000A4;
extern Vtx Bmori1_room_3Vtx_0000B0[];
extern Gfx Bmori1_room_3DL_0008F0[];
extern Vtx Bmori1_room_3Vtx_001040[];
extern Gfx Bmori1_room_3DL_001B80[];
extern Vtx Bmori1_room_3Vtx_001DE8[];
extern Gfx Bmori1_room_3DL_002128[];
extern Gfx Bmori1_room_3DL_0023B8[];
extern u64 Bmori1_room_3Tex_0023D8[];
extern u64 Bmori1_room_3Tex_002BD8[];
extern u64 Bmori1_room_3Tex_0033D8[];
extern u64 Bmori1_room_3Tex_0037D8[];
extern u64 Bmori1_room_3Tex_0038D8[];

#endif

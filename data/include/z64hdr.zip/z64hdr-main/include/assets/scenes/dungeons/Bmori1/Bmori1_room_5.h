#ifndef BMORI1_ROOM_5_H
#define BMORI1_ROOM_5_H 1

extern SceneCmd Bmori1_room_5Commands[];
extern s16 Bmori1_room_5ObjectList_000040[];
extern ActorEntry Bmori1_room_5ActorList_000050[];
extern PolygonType0 Bmori1_room_5PolygonType0_0000B0;
extern PolygonDlist Bmori1_room_5PolygonDlist_0000BC[1];
extern s32 Bmori1_room_5_terminatorMaybe_0000C4;
extern Vtx Bmori1_room_5Vtx_0000D0[];
extern Gfx Bmori1_room_5DL_000910[];
extern Vtx Bmori1_room_5Vtx_001088[];
extern Gfx Bmori1_room_5DL_001BC8[];
extern Vtx Bmori1_room_5Vtx_001E30[];
extern Gfx Bmori1_room_5DL_002170[];
extern Gfx Bmori1_room_5DL_0023B0[];
extern u64 Bmori1_room_5Tex_0023D0[];
extern u64 Bmori1_room_5Tex_0027D0[];
extern u64 Bmori1_room_5Tex_002FD0[];
extern u64 Bmori1_room_5Tex_0033D0[];
extern u64 Bmori1_room_5Tex_0034D0[];

#endif

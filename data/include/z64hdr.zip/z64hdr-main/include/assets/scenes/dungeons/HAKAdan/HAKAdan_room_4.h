#ifndef HAKADAN_ROOM_4_H
#define HAKADAN_ROOM_4_H 1

extern SceneCmd HAKAdan_room_4Commands[];
extern s16 HAKAdan_room_4ObjectList_000040[];
extern ActorEntry HAKAdan_room_4ActorList_000050[];
extern PolygonType2 HAKAdan_room_4PolygonType2_0000D0;
extern PolygonDlist2 HAKAdan_room_4PolygonDlist2_0000DC[3];
extern s32 HAKAdan_room_4_terminatorMaybe_00010C;
extern Vtx HAKAdan_room_4Vtx_000110[];
extern Gfx HAKAdan_room_4DL_000280[];
extern Vtx HAKAdan_room_4Vtx_0003B8[];
extern Gfx HAKAdan_room_4DL_000858[];
extern Vtx HAKAdan_room_4Vtx_0009F0[];
extern Gfx HAKAdan_room_4DL_001230[];
extern u64 HAKAdan_room_4Tex_001458[];

#endif

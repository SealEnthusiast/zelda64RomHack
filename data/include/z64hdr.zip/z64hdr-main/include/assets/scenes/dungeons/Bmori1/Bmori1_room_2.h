#ifndef BMORI1_ROOM_2_H
#define BMORI1_ROOM_2_H 1

extern SceneCmd Bmori1_room_2Commands[];
extern s16 Bmori1_room_2ObjectList_000040[];
extern ActorEntry Bmori1_room_2ActorList_00005C[];
extern PolygonType0 Bmori1_room_2PolygonType0_0001B0;
extern PolygonDlist Bmori1_room_2PolygonDlist_0001BC[1];
extern s32 Bmori1_room_2_terminatorMaybe_0001C4;
extern Vtx Bmori1_room_2Vtx_0001D0[];
extern Gfx Bmori1_room_2DL_000F50[];
extern Vtx Bmori1_room_2Vtx_0017E8[];
extern Gfx Bmori1_room_2DL_002AA8[];
extern Vtx Bmori1_room_2Vtx_003748[];
extern Gfx Bmori1_room_2DL_0038C8[];
extern Vtx Bmori1_room_2Vtx_0039C8[];
extern Gfx Bmori1_room_2DL_003FB8[];
extern Vtx Bmori1_room_2Vtx_0042F0[];
extern Gfx Bmori1_room_2DL_0048E0[];
extern Vtx Bmori1_room_2Vtx_004C00[];
extern Gfx Bmori1_room_2DL_005A00[];
extern Vtx Bmori1_room_2Vtx_0064E0[];
extern Gfx Bmori1_room_2DL_0072A0[];
extern Vtx Bmori1_room_2Vtx_007D78[];
extern Gfx Bmori1_room_2DL_0083E8[];
extern Vtx Bmori1_room_2Vtx_008880[];
extern Gfx Bmori1_room_2DL_008F80[];
extern Vtx Bmori1_room_2Vtx_009158[];
extern Gfx Bmori1_room_2DL_009D78[];
extern Gfx Bmori1_room_2DL_00A328[];
extern u64 Bmori1_room_2Tex_00A380[];
extern u64 Bmori1_room_2Tex_00AB80[];
extern u64 Bmori1_room_2Tex_00AF80[];
extern u64 Bmori1_room_2Tex_00BF80[];
extern u64 Bmori1_room_2Tex_00CF80[];
extern u64 Bmori1_room_2Tex_00D380[];
extern u64 Bmori1_room_2Tex_00DB80[];
extern u64 Bmori1_room_2Tex_00DD80[];
extern u64 Bmori1_room_2Tex_00E580[];
extern u64 Bmori1_room_2Tex_00E980[];
extern u64 Bmori1_room_2Tex_00F180[];

#endif

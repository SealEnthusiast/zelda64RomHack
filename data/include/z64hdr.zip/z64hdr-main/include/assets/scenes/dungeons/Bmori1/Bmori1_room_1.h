#ifndef BMORI1_ROOM_1_H
#define BMORI1_ROOM_1_H 1

extern SceneCmd Bmori1_room_1Commands[];
extern s16 Bmori1_room_1ObjectList_000040[];
extern ActorEntry Bmori1_room_1ActorList_000050[];
extern PolygonType0 Bmori1_room_1PolygonType0_000090;
extern PolygonDlist Bmori1_room_1PolygonDlist_00009C[1];
extern s32 Bmori1_room_1_terminatorMaybe_0000A4;
extern Vtx Bmori1_room_1Vtx_0000B0[];
extern Gfx Bmori1_room_1DL_0020F0[];
extern Vtx Bmori1_room_1Vtx_002F40[];
extern Gfx Bmori1_room_1DL_003260[];
extern Gfx Bmori1_room_1DL_003350[];
extern u64 Bmori1_room_1Tex_003368[];
extern u64 Bmori1_room_1Tex_003B68[];
extern u64 Bmori1_room_1Tex_004368[];
extern u64 Bmori1_room_1Tex_005368[];

#endif

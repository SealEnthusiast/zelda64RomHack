#ifndef BMORI1_ROOM_20_H
#define BMORI1_ROOM_20_H 1

extern SceneCmd Bmori1_room_20Commands[];
extern s16 Bmori1_room_20ObjectList_000040[];
extern ActorEntry Bmori1_room_20ActorList_000054[];
extern PolygonType0 Bmori1_room_20PolygonType0_0000B0;
extern PolygonDlist Bmori1_room_20PolygonDlist_0000BC[1];
extern s32 Bmori1_room_20_terminatorMaybe_0000C4;
extern Vtx Bmori1_room_20Vtx_0000D0[];
extern Gfx Bmori1_room_20DL_000450[];
extern Gfx Bmori1_room_20DL_0006E8[];
extern u64 Bmori1_room_20Tex_0006F8[];
extern u64 Bmori1_room_20Tex_000EF8[];

#endif

#ifndef HAKADAN_ROOM_22_H
#define HAKADAN_ROOM_22_H 1

extern SceneCmd HAKAdan_room_22Commands[];
extern s16 HAKAdan_room_22ObjectList_000038[];
extern PolygonType2 HAKAdan_room_22PolygonType2_000050;
extern PolygonDlist2 HAKAdan_room_22PolygonDlist2_00005C[1];
extern s32 HAKAdan_room_22_terminatorMaybe_00006C;
extern Vtx HAKAdan_room_22Vtx_000070[];
extern Gfx HAKAdan_room_22DL_000B00[];
extern u64 HAKAdan_room_22Tex_000FA8[];
extern u64 HAKAdan_room_22Tex_0011A8[];
extern u64 HAKAdan_room_22Tex_0021A8[];

#endif

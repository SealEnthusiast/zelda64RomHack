#ifndef BMORI1_ROOM_4_H
#define BMORI1_ROOM_4_H 1

extern SceneCmd Bmori1_room_4Commands[];
extern s16 Bmori1_room_4ObjectList_000040[];
extern ActorEntry Bmori1_room_4ActorList_000050[];
extern PolygonType0 Bmori1_room_4PolygonType0_000070;
extern PolygonDlist Bmori1_room_4PolygonDlist_00007C[1];
extern s32 Bmori1_room_4_terminatorMaybe_000084;
extern Vtx Bmori1_room_4Vtx_000090[];
extern Gfx Bmori1_room_4DL_001280[];
extern Gfx Bmori1_room_4DL_0022A8[];
extern u64 Bmori1_room_4Tex_0022B8[];
extern u64 Bmori1_room_4Tex_002AB8[];

#endif

#ifndef BMORI1_ROOM_15_H
#define BMORI1_ROOM_15_H 1

extern SceneCmd Bmori1_room_15Commands[];
extern s16 Bmori1_room_15ObjectList_000040[];
extern ActorEntry Bmori1_room_15ActorList_00004C[];
extern PolygonType0 Bmori1_room_15PolygonType0_000110;
extern PolygonDlist Bmori1_room_15PolygonDlist_00011C[1];
extern s32 Bmori1_room_15_terminatorMaybe_000124;
extern Vtx Bmori1_room_15Vtx_000130[];
extern Gfx Bmori1_room_15DL_000C90[];
extern Gfx Bmori1_room_15DL_0012D0[];
extern u64 Bmori1_room_15Tex_0012E0[];
extern u64 Bmori1_room_15Tex_001AE0[];
extern u64 Bmori1_room_15Tex_001EE0[];

#endif

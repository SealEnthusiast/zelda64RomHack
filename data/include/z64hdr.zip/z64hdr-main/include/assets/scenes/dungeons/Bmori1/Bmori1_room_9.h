#ifndef BMORI1_ROOM_9_H
#define BMORI1_ROOM_9_H 1

extern SceneCmd Bmori1_room_9Commands[];
extern s16 Bmori1_room_9ObjectList_000040[];
extern ActorEntry Bmori1_room_9ActorList_000054[];
extern PolygonType0 Bmori1_room_9PolygonType0_0000D0;
extern PolygonDlist Bmori1_room_9PolygonDlist_0000DC[1];
extern s32 Bmori1_room_9_terminatorMaybe_0000E4;
extern Vtx Bmori1_room_9Vtx_0000F0[];
extern Gfx Bmori1_room_9DL_0001C0[];
extern Vtx Bmori1_room_9Vtx_000280[];
extern Gfx Bmori1_room_9DL_000F00[];
extern Vtx Bmori1_room_9Vtx_0015B8[];
extern Gfx Bmori1_room_9DL_001898[];
extern Vtx Bmori1_room_9Vtx_001B20[];
extern Gfx Bmori1_room_9DL_003860[];
extern Vtx Bmori1_room_9Vtx_003E40[];
extern Gfx Bmori1_room_9DL_004000[];
extern Vtx Bmori1_room_9Vtx_004108[];
extern Gfx Bmori1_room_9DL_0044E8[];
extern Gfx Bmori1_room_9DL_004880[];
extern u64 Bmori1_room_9Tex_0048B8[];
extern u64 Bmori1_room_9Tex_0050B8[];
extern u64 Bmori1_room_9Tex_0054B8[];
extern u64 Bmori1_room_9Tex_005CB8[];
extern u64 Bmori1_room_9Tex_0064B8[];
extern u64 Bmori1_room_9Tex_006CB8[];
extern u64 Bmori1_room_9Tex_0074B8[];
extern Vtx Bmori1_room_9Vtx_0084C0[];
extern Gfx Bmori1_room_9DL_008680[];
extern Vtx Bmori1_room_9Vtx_008760[];
extern Gfx Bmori1_room_9DL_008870[];
extern Gfx Bmori1_room_9DL_008940[];
extern u64 Bmori1_room_9Tex_008958[];
extern u64 Bmori1_room_9Tex_009158[];

#endif

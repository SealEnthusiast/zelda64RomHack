#ifndef HAKADAN_ROOM_16_H
#define HAKADAN_ROOM_16_H 1

extern SceneCmd HAKAdan_room_16Commands[];
extern s16 HAKAdan_room_16ObjectList_000040[];
extern ActorEntry HAKAdan_room_16ActorList_000058[];
extern PolygonType2 HAKAdan_room_16PolygonType2_0001D0;
extern PolygonDlist2 HAKAdan_room_16PolygonDlist2_0001DC[2];
extern s32 HAKAdan_room_16_terminatorMaybe_0001FC;
extern Vtx HAKAdan_room_16Vtx_000200[];
extern Gfx HAKAdan_room_16DL_001400[];
extern Vtx HAKAdan_room_16Vtx_001788[];
extern Gfx HAKAdan_room_16DL_001858[];
extern u64 HAKAdan_room_16Tex_001930[];

#endif

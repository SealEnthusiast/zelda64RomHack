#ifndef HAKADAN_ROOM_9_H
#define HAKADAN_ROOM_9_H 1

extern SceneCmd HAKAdan_room_9Commands[];
extern s16 HAKAdan_room_9ObjectList_000040[];
extern ActorEntry HAKAdan_room_9ActorList_000058[];
extern PolygonType2 HAKAdan_room_9PolygonType2_000240;
extern PolygonDlist2 HAKAdan_room_9PolygonDlist2_00024C[11];
extern s32 HAKAdan_room_9_terminatorMaybe_0002FC;
extern Vtx HAKAdan_room_9Vtx_000300[];
extern Gfx HAKAdan_room_9DL_000470[];
extern Vtx HAKAdan_room_9Vtx_0005B8[];
extern Gfx HAKAdan_room_9DL_000868[];
extern Vtx HAKAdan_room_9Vtx_0009B8[];
extern Gfx HAKAdan_room_9DL_002248[];
extern Vtx HAKAdan_room_9Vtx_002720[];
extern Gfx HAKAdan_room_9DL_003E30[];
extern Vtx HAKAdan_room_9Vtx_004CD0[];
extern Gfx HAKAdan_room_9DL_005AF0[];
extern Vtx HAKAdan_room_9Vtx_006000[];
extern Gfx HAKAdan_room_9DL_006600[];
extern Vtx HAKAdan_room_9Vtx_006820[];
extern Gfx HAKAdan_room_9DL_007620[];
extern Vtx HAKAdan_room_9Vtx_0078F8[];
extern Gfx HAKAdan_room_9DL_008058[];
extern Vtx HAKAdan_room_9Vtx_0082E8[];
extern Gfx HAKAdan_room_9DL_0085F8[];
extern Vtx HAKAdan_room_9Vtx_008770[];
extern Gfx HAKAdan_room_9DL_008910[];
extern Vtx HAKAdan_room_9Vtx_008A58[];
extern Gfx HAKAdan_room_9DL_008E68[];
extern u64 HAKAdan_room_9Tex_009090[];
extern u64 HAKAdan_room_9Tex_009890[];
extern u64 HAKAdan_room_9Tex_00A090[];
extern u64 HAKAdan_room_9Tex_00A290[];
extern u64 HAKAdan_room_9Tex_00B290[];
extern u64 HAKAdan_room_9Tex_00BA90[];
extern u64 HAKAdan_room_9Tex_00BE90[];
extern u64 HAKAdan_room_9Tex_00C690[];
extern u64 HAKAdan_room_9Tex_00C890[];

#endif

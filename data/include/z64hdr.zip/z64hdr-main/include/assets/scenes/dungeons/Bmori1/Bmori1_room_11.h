#ifndef BMORI1_ROOM_11_H
#define BMORI1_ROOM_11_H 1

extern SceneCmd Bmori1_room_11Commands[];
extern s16 Bmori1_room_11ObjectList_000040[];
extern ActorEntry Bmori1_room_11ActorList_000058[];
extern PolygonType0 Bmori1_room_11PolygonType0_0001C0;
extern PolygonDlist Bmori1_room_11PolygonDlist_0001CC[1];
extern s32 Bmori1_room_11_terminatorMaybe_0001D4;
extern Vtx Bmori1_room_11Vtx_0001E0[];
extern Gfx Bmori1_room_11DL_002620[];
extern Vtx Bmori1_room_11Vtx_0034E0[];
extern Gfx Bmori1_room_11DL_0057F0[];
extern Vtx Bmori1_room_11Vtx_007398[];
extern Gfx Bmori1_room_11DL_007618[];
extern Vtx Bmori1_room_11Vtx_007708[];
extern Gfx Bmori1_room_11DL_007848[];
extern Vtx Bmori1_room_11Vtx_007918[];
extern Gfx Bmori1_room_11DL_007BE8[];
extern Vtx Bmori1_room_11Vtx_007E10[];
extern Gfx Bmori1_room_11DL_007EF0[];
extern Vtx Bmori1_room_11Vtx_007FE0[];
extern Gfx Bmori1_room_11DL_0080A0[];
extern Gfx Bmori1_room_11DL_008158[];
extern u64 Bmori1_room_11Tex_008198[];
extern u64 Bmori1_room_11Tex_009198[];
extern u64 Bmori1_room_11Tex_009598[];
extern u64 Bmori1_room_11Tex_009D98[];
extern u64 Bmori1_room_11Tex_00A598[];
extern Vtx Bmori1_room_11Vtx_00A9A0[];
extern Gfx Bmori1_room_11DL_00AB40[];
extern Gfx Bmori1_room_11DL_00ABD0[];

#endif

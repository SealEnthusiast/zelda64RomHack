#ifndef HIDAN_ROOM_16_H
#define HIDAN_ROOM_16_H 1

extern SceneCmd HIDAN_room_16Commands[];
extern s16 HIDAN_room_16ObjectList_000040[];
extern ActorEntry HIDAN_room_16ActorList_00004C[];
extern PolygonType2 HIDAN_room_16PolygonType2_000170;
extern PolygonDlist2 HIDAN_room_16PolygonDlist2_00017C[4];
extern s32 HIDAN_room_16_terminatorMaybe_0001BC;
extern Vtx HIDAN_room_16Vtx_0001C0[];
extern Gfx HIDAN_room_16DL_000350[];
extern Vtx HIDAN_room_16Vtx_000480[];
extern Gfx HIDAN_room_16DL_001480[];
extern Vtx HIDAN_room_16Vtx_002318[];
extern Gfx HIDAN_room_16DL_003B58[];
extern Vtx HIDAN_room_16Vtx_004E38[];
extern Gfx HIDAN_room_16DL_005ED8[];
extern u64 HIDAN_room_16Tex_006DE0[];
extern u64 HIDAN_room_16Tex_006FE0[];
extern u64 HIDAN_room_16Tex_0077E0[];
extern u64 HIDAN_room_16Tex_007FE0[];
extern u64 HIDAN_room_16Tex_0083E0[];
extern u64 HIDAN_room_16Tex_0085E0[];
extern u64 HIDAN_room_16Tex_008DE0[];
extern u64 HIDAN_room_16Tex_0091E0[];
extern u64 HIDAN_room_16Tex_0095E0[];
extern u64 HIDAN_room_16Tex_009DE0[];
extern u64 HIDAN_room_16Tex_00A5E0[];
extern u64 HIDAN_room_16Tex_00A9E0[];
extern u64 HIDAN_room_16Tex_00B1E0[];

#endif

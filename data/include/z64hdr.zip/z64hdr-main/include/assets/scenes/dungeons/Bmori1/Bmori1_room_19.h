#ifndef BMORI1_ROOM_19_H
#define BMORI1_ROOM_19_H 1

extern SceneCmd Bmori1_room_19Commands[];
extern s16 Bmori1_room_19ObjectList_000040[];
extern ActorEntry Bmori1_room_19ActorList_000054[];
extern PolygonType0 Bmori1_room_19PolygonType0_0000A0;
extern PolygonDlist Bmori1_room_19PolygonDlist_0000AC[1];
extern s32 Bmori1_room_19_terminatorMaybe_0000B4;
extern Vtx Bmori1_room_19Vtx_0000C0[];
extern Gfx Bmori1_room_19DL_0003B0[];
extern Gfx Bmori1_room_19DL_0004F0[];

#endif

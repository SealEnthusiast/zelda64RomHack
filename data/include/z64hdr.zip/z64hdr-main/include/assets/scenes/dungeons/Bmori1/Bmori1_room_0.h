#ifndef BMORI1_ROOM_0_H
#define BMORI1_ROOM_0_H 1

extern SceneCmd Bmori1_room_0Commands[];
extern s16 Bmori1_room_0ObjectList_000040[];
extern ActorEntry Bmori1_room_0ActorList_000050[];
extern PolygonType0 Bmori1_room_0PolygonType0_0000D0;
extern PolygonDlist Bmori1_room_0PolygonDlist_0000DC[1];
extern s32 Bmori1_room_0_terminatorMaybe_0000E4;
extern Vtx Bmori1_room_0Vtx_0000F0[];
extern Gfx Bmori1_room_0DL_001CE0[];
extern Vtx Bmori1_room_0Vtx_0031E0[];
extern Gfx Bmori1_room_0DL_003D70[];
extern Vtx Bmori1_room_0Vtx_0041F0[];
extern Gfx Bmori1_room_0DL_004510[];
extern Vtx Bmori1_room_0Vtx_0046B8[];
extern Gfx Bmori1_room_0DL_0052E8[];
extern Vtx Bmori1_room_0Vtx_0057D0[];
extern Gfx Bmori1_room_0DL_005B60[];
extern Gfx Bmori1_room_0DL_005CC8[];
extern u64 Bmori1_room_0Tex_005CF8[];
extern u64 Bmori1_room_0Tex_0064F8[];
extern u64 Bmori1_room_0Tex_0074F8[];
extern u64 Bmori1_room_0Tex_007CF8[];
extern u64 Bmori1_room_0Tex_0084F8[];
extern u64 Bmori1_room_0Tex_0088F8[];
extern u64 Bmori1_room_0Tex_0098F8[];
extern u64 Bmori1_room_0Tex_00A0F8[];
extern u64 Bmori1_room_0Tex_00B0F8[];
extern u64 Bmori1_room_0Tex_00B4F8[];
extern u64 Bmori1_room_0Tex_00B8F8[];
extern u64 Bmori1_room_0Tex_00C0F8[];
extern u64 Bmori1_room_0Tex_00C2F8[];
extern Vtx Bmori1_room_0Vtx_00C700[];
extern Gfx Bmori1_room_0DL_00C840[];
extern Vtx Bmori1_room_0Vtx_00C918[];
extern Gfx Bmori1_room_0DL_00CA78[];
extern Gfx Bmori1_room_0DL_00CB70[];
extern u64 Bmori1_room_0Tex_00CB88[];

#endif

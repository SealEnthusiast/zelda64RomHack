#ifndef HAKADAN_ROOM_20_H
#define HAKADAN_ROOM_20_H 1

extern SceneCmd HAKAdan_room_20Commands[];
extern s16 HAKAdan_room_20ObjectList_000040[];
extern ActorEntry HAKAdan_room_20ActorList_000050[];
extern PolygonType2 HAKAdan_room_20PolygonType2_000100;
extern PolygonDlist2 HAKAdan_room_20PolygonDlist2_00010C[3];
extern s32 HAKAdan_room_20_terminatorMaybe_00013C;
extern Vtx HAKAdan_room_20Vtx_000140[];
extern Gfx HAKAdan_room_20DL_0002B0[];
extern Vtx HAKAdan_room_20Vtx_0003E8[];
extern Gfx HAKAdan_room_20DL_000818[];
extern Vtx HAKAdan_room_20Vtx_0009A0[];
extern Gfx HAKAdan_room_20DL_0013D0[];
extern u64 HAKAdan_room_20Tex_001640[];

#endif

#ifndef BMORI1_ROOM_17_H
#define BMORI1_ROOM_17_H 1

extern SceneCmd Bmori1_room_17Commands[];
extern s16 Bmori1_room_17ObjectList_000040[];
extern ActorEntry Bmori1_room_17ActorList_000050[];
extern PolygonType0 Bmori1_room_17PolygonType0_000140;
extern PolygonDlist Bmori1_room_17PolygonDlist_00014C[1];
extern s32 Bmori1_room_17_terminatorMaybe_000154;
extern Vtx Bmori1_room_17Vtx_000160[];
extern Gfx Bmori1_room_17DL_000900[];
extern Vtx Bmori1_room_17Vtx_000B28[];
extern Gfx Bmori1_room_17DL_000E18[];
extern Vtx Bmori1_room_17Vtx_000F60[];
extern Gfx Bmori1_room_17DL_001250[];
extern Vtx Bmori1_room_17Vtx_001398[];
extern Gfx Bmori1_room_17DL_001688[];
extern Vtx Bmori1_room_17Vtx_0017D0[];
extern Gfx Bmori1_room_17DL_001C50[];
extern Vtx Bmori1_room_17Vtx_001DB8[];
extern Gfx Bmori1_room_17DL_003A48[];
extern Vtx Bmori1_room_17Vtx_004990[];
extern Gfx Bmori1_room_17DL_004A50[];
extern Vtx Bmori1_room_17Vtx_004B08[];
extern Gfx Bmori1_room_17DL_004D18[];
extern Vtx Bmori1_room_17Vtx_004FD8[];
extern Gfx Bmori1_room_17DL_005828[];
extern Vtx Bmori1_room_17Vtx_005E38[];
extern Gfx Bmori1_room_17DL_0062B8[];
extern Gfx Bmori1_room_17DL_006490[];
extern u64 Bmori1_room_17Tex_0064E8[];
extern u64 Bmori1_room_17Tex_006CE8[];
extern u64 Bmori1_room_17Tex_0074E8[];
extern u64 Bmori1_room_17Tex_0078E8[];
extern u64 Bmori1_room_17Tex_007CE8[];
extern u64 Bmori1_room_17Tex_0080E8[];
extern u64 Bmori1_room_17Tex_0088E8[];

#endif

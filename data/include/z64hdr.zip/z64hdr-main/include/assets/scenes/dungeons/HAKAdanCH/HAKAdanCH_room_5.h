#ifndef HAKADANCH_ROOM_5_H
#define HAKADANCH_ROOM_5_H 1

extern SceneCmd HAKAdanCH_room_5Commands[];
extern s16 HAKAdanCH_room_5ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_5ActorList_00005C[];
extern PolygonType2 HAKAdanCH_room_5PolygonType2_0000F0;
extern PolygonDlist2 HAKAdanCH_room_5PolygonDlist2_0000FC[5];
extern s32 HAKAdanCH_room_5_terminatorMaybe_00014C;
extern Vtx HAKAdanCH_room_5Vtx_000150[];
extern Gfx HAKAdanCH_room_5DL_000270[];
extern Vtx HAKAdanCH_room_5Vtx_000350[];
extern Gfx HAKAdanCH_room_5DL_000420[];
extern Vtx HAKAdanCH_room_5Vtx_000518[];
extern Gfx HAKAdanCH_room_5DL_000C18[];
extern Vtx HAKAdanCH_room_5Vtx_000E10[];
extern Gfx HAKAdanCH_room_5DL_000F10[];
extern Vtx HAKAdanCH_room_5Vtx_000FD0[];
extern Gfx HAKAdanCH_room_5DL_0010A0[];
extern u64 HAKAdanCH_room_5Tex_001190[];
extern u64 HAKAdanCH_room_5Tex_002190[];

#endif

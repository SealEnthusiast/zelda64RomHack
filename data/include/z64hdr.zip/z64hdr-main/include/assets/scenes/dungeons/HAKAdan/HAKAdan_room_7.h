#ifndef HAKADAN_ROOM_7_H
#define HAKADAN_ROOM_7_H 1

extern SceneCmd HAKAdan_room_7Commands[];
extern s16 HAKAdan_room_7ObjectList_000040[];
extern ActorEntry HAKAdan_room_7ActorList_00004C[];
extern PolygonType2 HAKAdan_room_7PolygonType2_0000B0;
extern PolygonDlist2 HAKAdan_room_7PolygonDlist2_0000BC[3];
extern s32 HAKAdan_room_7_terminatorMaybe_0000EC;
extern Vtx HAKAdan_room_7Vtx_0000F0[];
extern Gfx HAKAdan_room_7DL_000260[];
extern Vtx HAKAdan_room_7Vtx_000398[];
extern Gfx HAKAdan_room_7DL_0008E8[];
extern Vtx HAKAdan_room_7Vtx_000AA0[];
extern Gfx HAKAdan_room_7DL_001100[];
extern u64 HAKAdan_room_7Tex_0012D8[];

#endif

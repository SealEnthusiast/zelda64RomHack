#ifndef FIRE_BS_ROOM_0_H
#define FIRE_BS_ROOM_0_H 1

extern SceneCmd FIRE_bs_room_0Commands[];
extern s16 FIRE_bs_room_0ObjectList_000038[];
extern PolygonType0 FIRE_bs_room_0PolygonType0_000050;
extern PolygonDlist FIRE_bs_room_0PolygonDlist_00005C[1];
extern s32 FIRE_bs_room_0_terminatorMaybe_000064;
extern Vtx FIRE_bs_room_0Vtx_000070[];
extern Gfx FIRE_bs_room_0DL_001F20[];
extern Vtx FIRE_bs_room_0Vtx_0026C8[];
extern Gfx FIRE_bs_room_0DL_002848[];
extern Vtx FIRE_bs_room_0Vtx_002978[];
extern Gfx FIRE_bs_room_0DL_002C78[];
extern Gfx FIRE_bs_room_0DL_002E08[];
extern u64 FIRE_bs_room_0TLUT_002E28[];
extern u64 FIRE_bs_room_0TLUT_002E48[];
extern u64 FIRE_bs_room_0Tex_002E68[];
extern u64 FIRE_bs_room_0Tex_003068[];
extern u64 FIRE_bs_room_0Tex_003468[];
extern u64 FIRE_bs_room_0Tex_003868[];
extern u64 FIRE_bs_room_0Tex_003A68[];
extern u64 FIRE_bs_room_0Tex_003C68[];
extern u64 FIRE_bs_room_0Tex_004068[];

#endif

#ifndef HIDAN_ROOM_12_H
#define HIDAN_ROOM_12_H 1

extern SceneCmd HIDAN_room_12Commands[];
extern s16 HIDAN_room_12ObjectList_000040[];
extern ActorEntry HIDAN_room_12ActorList_000050[];
extern PolygonType2 HIDAN_room_12PolygonType2_000060;
extern PolygonDlist2 HIDAN_room_12PolygonDlist2_00006C[3];
extern s32 HIDAN_room_12_terminatorMaybe_00009C;
extern Vtx HIDAN_room_12Vtx_0000A0[];
extern Gfx HIDAN_room_12DL_000B70[];
extern Vtx HIDAN_room_12Vtx_0013C0[];
extern Gfx HIDAN_room_12DL_001520[];
extern Vtx HIDAN_room_12Vtx_001628[];
extern Gfx HIDAN_room_12DL_001A58[];
extern u64 HIDAN_room_12Tex_001D68[];
extern u64 HIDAN_room_12Tex_001F68[];
extern u64 HIDAN_room_12Tex_002768[];

#endif

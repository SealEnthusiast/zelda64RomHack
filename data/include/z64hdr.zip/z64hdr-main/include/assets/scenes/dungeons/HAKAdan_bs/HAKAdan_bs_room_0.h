#ifndef HAKADAN_BS_ROOM_0_H
#define HAKADAN_BS_ROOM_0_H 1

extern SceneCmd HAKAdan_bs_room_0Commands[];
extern s16 HAKAdan_bs_room_0ObjectList_000040[];
extern ActorEntry HAKAdan_bs_room_0ActorList_00004C[];
extern PolygonType0 HAKAdan_bs_room_0PolygonType0_0000B0;
extern PolygonDlist HAKAdan_bs_room_0PolygonDlist_0000BC[1];
extern s32 HAKAdan_bs_room_0_terminatorMaybe_0000C4;
extern Vtx HAKAdan_bs_room_0Vtx_0000D0[];
extern Gfx HAKAdan_bs_room_0DL_0005E0[];
extern Vtx HAKAdan_bs_room_0Vtx_000748[];
extern Gfx HAKAdan_bs_room_0DL_000D68[];
extern Vtx HAKAdan_bs_room_0Vtx_000F98[];
extern Gfx HAKAdan_bs_room_0DL_0019D8[];
extern Vtx HAKAdan_bs_room_0Vtx_001C48[];
extern Gfx HAKAdan_bs_room_0DL_001E78[];
extern Vtx HAKAdan_bs_room_0Vtx_001F70[];
extern Gfx HAKAdan_bs_room_0DL_0020D0[];
extern Gfx HAKAdan_bs_room_0DL_0021B0[];
extern u64 HAKAdan_bs_room_0Tex_0021E0[];
extern u64 HAKAdan_bs_room_0Tex_0023E0[];
extern u64 HAKAdan_bs_room_0Tex_0027E0[];

#endif

#ifndef HIDAN_ROOM_17_H
#define HIDAN_ROOM_17_H 1

extern SceneCmd HIDAN_room_17Commands[];
extern s16 HIDAN_room_17ObjectList_000040[];
extern ActorEntry HIDAN_room_17ActorList_00004C[];
extern PolygonType2 HIDAN_room_17PolygonType2_000110;
extern PolygonDlist2 HIDAN_room_17PolygonDlist2_00011C[1];
extern s32 HIDAN_room_17_terminatorMaybe_00012C;
extern Vtx HIDAN_room_17Vtx_000130[];
extern Gfx HIDAN_room_17DL_003290[];
extern u64 HIDAN_room_17Tex_005168[];
extern u64 HIDAN_room_17Tex_005968[];
extern u64 HIDAN_room_17Tex_006168[];
extern u64 HIDAN_room_17Tex_006968[];
extern u64 HIDAN_room_17Tex_007168[];
extern u64 HIDAN_room_17Tex_007968[];
extern u64 HIDAN_room_17Tex_008168[];
extern u64 HIDAN_room_17Tex_008968[];

#endif

#ifndef HAKADAN_ROOM_3_H
#define HAKADAN_ROOM_3_H 1

extern SceneCmd HAKAdan_room_3Commands[];
extern s16 HAKAdan_room_3ObjectList_000040[];
extern ActorEntry HAKAdan_room_3ActorList_000050[];
extern PolygonType2 HAKAdan_room_3PolygonType2_000070;
extern PolygonDlist2 HAKAdan_room_3PolygonDlist2_00007C[4];
extern s32 HAKAdan_room_3_terminatorMaybe_0000BC;
extern Vtx HAKAdan_room_3Vtx_0000C0[];
extern Gfx HAKAdan_room_3DL_000750[];
extern Vtx HAKAdan_room_3Vtx_000950[];
extern Gfx HAKAdan_room_3DL_000CB0[];
extern Vtx HAKAdan_room_3Vtx_000F30[];
extern Gfx HAKAdan_room_3DL_0011B0[];
extern Vtx HAKAdan_room_3Vtx_0012C0[];
extern Gfx HAKAdan_room_3DL_001420[];
extern u64 HAKAdan_room_3Tex_001578[];
extern u64 HAKAdan_room_3Tex_001D78[];
extern u64 HAKAdan_room_3Tex_002578[];
extern u64 HAKAdan_room_3Tex_002778[];

#endif

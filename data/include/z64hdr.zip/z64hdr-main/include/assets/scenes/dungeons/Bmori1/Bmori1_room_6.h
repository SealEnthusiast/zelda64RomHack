#ifndef BMORI1_ROOM_6_H
#define BMORI1_ROOM_6_H 1

extern SceneCmd Bmori1_room_6Commands[];
extern s16 Bmori1_room_6ObjectList_000040[];
extern ActorEntry Bmori1_room_6ActorList_000054[];
extern PolygonType0 Bmori1_room_6PolygonType0_000120;
extern PolygonDlist Bmori1_room_6PolygonDlist_00012C[1];
extern s32 Bmori1_room_6_terminatorMaybe_000134;
extern Vtx Bmori1_room_6Vtx_000140[];
extern Gfx Bmori1_room_6DL_0006C0[];
extern Vtx Bmori1_room_6Vtx_000DD8[];
extern Gfx Bmori1_room_6DL_001D68[];
extern Vtx Bmori1_room_6Vtx_002988[];
extern Gfx Bmori1_room_6DL_002E48[];
extern Vtx Bmori1_room_6Vtx_002F98[];
extern Gfx Bmori1_room_6DL_003538[];
extern Vtx Bmori1_room_6Vtx_0039E8[];
extern Gfx Bmori1_room_6DL_003B78[];
extern Vtx Bmori1_room_6Vtx_003DB8[];
extern Gfx Bmori1_room_6DL_0041C8[];
extern Vtx Bmori1_room_6Vtx_0044B8[];
extern Gfx Bmori1_room_6DL_004648[];
extern Vtx Bmori1_room_6Vtx_004888[];
extern Gfx Bmori1_room_6DL_0050A8[];
extern Vtx Bmori1_room_6Vtx_005688[];
extern Gfx Bmori1_room_6DL_005818[];
extern Vtx Bmori1_room_6Vtx_005A58[];
extern Gfx Bmori1_room_6DL_005E28[];
extern Vtx Bmori1_room_6Vtx_006158[];
extern Gfx Bmori1_room_6DL_006318[];
extern Gfx Bmori1_room_6DL_0065D0[];
extern u64 Bmori1_room_6Tex_006630[];
extern u64 Bmori1_room_6Tex_006E30[];
extern u64 Bmori1_room_6Tex_007630[];
extern u64 Bmori1_room_6Tex_007A30[];
extern u64 Bmori1_room_6Tex_008230[];
extern u64 Bmori1_room_6Tex_008A30[];
extern u64 Bmori1_room_6Tex_008C30[];

#endif

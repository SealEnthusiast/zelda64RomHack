#ifndef HAKADANCH_ROOM_2_H
#define HAKADANCH_ROOM_2_H 1

extern SceneCmd HAKAdanCH_room_2Commands[];
extern s16 HAKAdanCH_room_2ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_2ActorList_000050[];
extern PolygonType2 HAKAdanCH_room_2PolygonType2_000110;
extern PolygonDlist2 HAKAdanCH_room_2PolygonDlist2_00011C[3];
extern s32 HAKAdanCH_room_2_terminatorMaybe_00014C;
extern Vtx HAKAdanCH_room_2Vtx_000150[];
extern Gfx HAKAdanCH_room_2DL_0006E0[];
extern Vtx HAKAdanCH_room_2Vtx_0008A0[];
extern Gfx HAKAdanCH_room_2DL_0009E0[];
extern Vtx HAKAdanCH_room_2Vtx_000AA8[];
extern Gfx HAKAdanCH_room_2DL_001FA8[];
extern u64 HAKAdanCH_room_2Tex_002958[];
extern u64 HAKAdanCH_room_2Tex_002B58[];
extern u64 HAKAdanCH_room_2Tex_002D58[];
extern u64 HAKAdanCH_room_2Tex_002F58[];

#endif

#ifndef HIDAN_ROOM_15_H
#define HIDAN_ROOM_15_H 1

extern SceneCmd HIDAN_room_15Commands[];
extern s16 HIDAN_room_15ObjectList_000040[];
extern ActorEntry HIDAN_room_15ActorList_000048[];
extern PolygonType2 HIDAN_room_15PolygonType2_000090;
extern PolygonDlist2 HIDAN_room_15PolygonDlist2_00009C[1];
extern s32 HIDAN_room_15_terminatorMaybe_0000AC;
extern Vtx HIDAN_room_15Vtx_0000B0[];
extern Gfx HIDAN_room_15DL_000910[];
extern u64 HIDAN_room_15Tex_000D88[];

#endif

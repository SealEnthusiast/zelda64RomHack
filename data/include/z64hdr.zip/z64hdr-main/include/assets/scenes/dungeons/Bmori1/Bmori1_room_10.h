#ifndef BMORI1_ROOM_10_H
#define BMORI1_ROOM_10_H 1

extern SceneCmd Bmori1_room_10Commands[];
extern s16 Bmori1_room_10ObjectList_000040[];
extern ActorEntry Bmori1_room_10ActorList_000054[];
extern PolygonType0 Bmori1_room_10PolygonType0_000090;
extern PolygonDlist Bmori1_room_10PolygonDlist_00009C[1];
extern s32 Bmori1_room_10_terminatorMaybe_0000A4;
extern Vtx Bmori1_room_10Vtx_0000B0[];
extern Gfx Bmori1_room_10DL_0008D0[];
extern Vtx Bmori1_room_10Vtx_000F20[];
extern Gfx Bmori1_room_10DL_0010E0[];
extern Gfx Bmori1_room_10DL_001248[];
extern u64 Bmori1_room_10Tex_001260[];
extern u64 Bmori1_room_10Tex_001A60[];
extern u64 Bmori1_room_10Tex_002260[];
extern u64 Bmori1_room_10Tex_002A60[];
extern u64 Bmori1_room_10Tex_003A60[];
extern Vtx Bmori1_room_10Vtx_004A60[];
extern Gfx Bmori1_room_10DL_004B10[];
extern Gfx Bmori1_room_10DL_004BC8[];
extern u64 Bmori1_room_10Tex_004BD8[];

#endif

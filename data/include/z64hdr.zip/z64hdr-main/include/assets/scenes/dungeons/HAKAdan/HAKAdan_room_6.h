#ifndef HAKADAN_ROOM_6_H
#define HAKADAN_ROOM_6_H 1

extern SceneCmd HAKAdan_room_6Commands[];
extern s16 HAKAdan_room_6ObjectList_000040[];
extern ActorEntry HAKAdan_room_6ActorList_00005C[];
extern PolygonType2 HAKAdan_room_6PolygonType2_000160;
extern PolygonDlist2 HAKAdan_room_6PolygonDlist2_00016C[3];
extern s32 HAKAdan_room_6_terminatorMaybe_00019C;
extern Vtx HAKAdan_room_6Vtx_0001A0[];
extern Gfx HAKAdan_room_6DL_001B40[];
extern Vtx HAKAdan_room_6Vtx_002018[];
extern Gfx HAKAdan_room_6DL_004178[];
extern Vtx HAKAdan_room_6Vtx_004A58[];
extern Gfx HAKAdan_room_6DL_004B18[];
extern u64 HAKAdan_room_6Tex_004BF0[];
extern u64 HAKAdan_room_6Tex_0053F0[];
extern u64 HAKAdan_room_6Tex_0055F0[];
extern u64 HAKAdan_room_6Tex_0065F0[];
extern u64 HAKAdan_room_6Tex_006DF0[];
extern u64 HAKAdan_room_6Tex_0071F0[];

#endif

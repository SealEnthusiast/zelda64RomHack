#ifndef HAKADAN_ROOM_1_H
#define HAKADAN_ROOM_1_H 1

extern SceneCmd HAKAdan_room_1Commands[];
extern s16 HAKAdan_room_1ObjectList_000040[];
extern ActorEntry HAKAdan_room_1ActorList_000050[];
extern PolygonType2 HAKAdan_room_1PolygonType2_0000C0;
extern PolygonDlist2 HAKAdan_room_1PolygonDlist2_0000CC[3];
extern s32 HAKAdan_room_1_terminatorMaybe_0000FC;
extern Vtx HAKAdan_room_1Vtx_000100[];
extern Gfx HAKAdan_room_1DL_000270[];
extern Vtx HAKAdan_room_1Vtx_0003A8[];
extern Gfx HAKAdan_room_1DL_0008F8[];
extern Vtx HAKAdan_room_1Vtx_000AB0[];
extern Gfx HAKAdan_room_1DL_001110[];
extern u64 HAKAdan_room_1Tex_0012E8[];

#endif

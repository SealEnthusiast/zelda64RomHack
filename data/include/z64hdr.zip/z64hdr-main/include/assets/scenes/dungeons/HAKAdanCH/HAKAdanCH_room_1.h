#ifndef HAKADANCH_ROOM_1_H
#define HAKADANCH_ROOM_1_H 1

extern SceneCmd HAKAdanCH_room_1Commands[];
extern s16 HAKAdanCH_room_1ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_1ActorList_00005C[];
extern PolygonType2 HAKAdanCH_room_1PolygonType2_000240;
extern PolygonDlist2 HAKAdanCH_room_1PolygonDlist2_00024C[9];
extern s32 HAKAdanCH_room_1_terminatorMaybe_0002DC;
extern Vtx HAKAdanCH_room_1Vtx_0002E0[];
extern Gfx HAKAdanCH_room_1DL_000A70[];
extern Vtx HAKAdanCH_room_1Vtx_000CC8[];
extern Gfx HAKAdanCH_room_1DL_0018D8[];
extern Vtx HAKAdanCH_room_1Vtx_001C00[];
extern Gfx HAKAdanCH_room_1DL_0040C0[];
extern Vtx HAKAdanCH_room_1Vtx_0059B0[];
extern Gfx HAKAdanCH_room_1DL_005E60[];
extern Vtx HAKAdanCH_room_1Vtx_0062C8[];
extern Gfx HAKAdanCH_room_1DL_0067E8[];
extern Vtx HAKAdanCH_room_1Vtx_0069D8[];
extern Gfx HAKAdanCH_room_1DL_007358[];
extern Vtx HAKAdanCH_room_1Vtx_0075C8[];
extern Gfx HAKAdanCH_room_1DL_007EA8[];
extern Vtx HAKAdanCH_room_1Vtx_008110[];
extern Gfx HAKAdanCH_room_1DL_008B10[];
extern u64 HAKAdanCH_room_1Tex_008D58[];
extern u64 HAKAdanCH_room_1Tex_008F58[];
extern u64 HAKAdanCH_room_1Tex_009158[];
extern u64 HAKAdanCH_room_1Tex_009358[];
extern u64 HAKAdanCH_room_1Tex_009758[];
extern u64 HAKAdanCH_room_1Tex_009F58[];
extern u64 HAKAdanCH_room_1Tex_00A158[];
extern u64 HAKAdanCH_room_1Tex_00A558[];
extern u64 HAKAdanCH_room_1Tex_00AD58[];
extern Vtx HAKAdanCH_room_1Vtx_00AF60[];
extern Gfx HAKAdanCH_room_1DL_00B040[];

#endif

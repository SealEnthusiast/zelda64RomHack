#ifndef HAKADAN_ROOM_19_H
#define HAKADAN_ROOM_19_H 1

extern SceneCmd HAKAdan_room_19Commands[];
extern s16 HAKAdan_room_19ObjectList_000040[];
extern ActorEntry HAKAdan_room_19ActorList_000050[];
extern PolygonType2 HAKAdan_room_19PolygonType2_0000D0;
extern PolygonDlist2 HAKAdan_room_19PolygonDlist2_0000DC[4];
extern s32 HAKAdan_room_19_terminatorMaybe_00011C;
extern Vtx HAKAdan_room_19Vtx_000120[];
extern Gfx HAKAdan_room_19DL_000290[];
extern Vtx HAKAdan_room_19Vtx_0003C8[];
extern Gfx HAKAdan_room_19DL_000938[];
extern Vtx HAKAdan_room_19Vtx_000B00[];
extern Gfx HAKAdan_room_19DL_0011E0[];
extern Vtx HAKAdan_room_19Vtx_0013C0[];
extern Gfx HAKAdan_room_19DL_001490[];
extern u64 HAKAdan_room_19Tex_001578[];
extern u64 HAKAdan_room_19Tex_002578[];

#endif

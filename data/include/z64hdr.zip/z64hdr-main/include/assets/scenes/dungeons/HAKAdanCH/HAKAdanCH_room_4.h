#ifndef HAKADANCH_ROOM_4_H
#define HAKADANCH_ROOM_4_H 1

extern SceneCmd HAKAdanCH_room_4Commands[];
extern s16 HAKAdanCH_room_4ObjectList_000040[];
extern ActorEntry HAKAdanCH_room_4ActorList_00004C[];
extern PolygonType2 HAKAdanCH_room_4PolygonType2_000110;
extern PolygonDlist2 HAKAdanCH_room_4PolygonDlist2_00011C[3];
extern s32 HAKAdanCH_room_4_terminatorMaybe_00014C;
extern Vtx HAKAdanCH_room_4Vtx_000150[];
extern Gfx HAKAdanCH_room_4DL_0002C0[];
extern Vtx HAKAdanCH_room_4Vtx_0003F8[];
extern Gfx HAKAdanCH_room_4DL_000898[];
extern Vtx HAKAdanCH_room_4Vtx_000A30[];
extern Gfx HAKAdanCH_room_4DL_001270[];
extern u64 HAKAdanCH_room_4Tex_001498[];
extern u64 HAKAdanCH_room_4Tex_001C98[];

#endif

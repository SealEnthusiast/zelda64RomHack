#ifndef BMORI1_ROOM_13_H
#define BMORI1_ROOM_13_H 1

extern SceneCmd Bmori1_room_13Commands[];
extern s16 Bmori1_room_13ObjectList_000040[];
extern ActorEntry Bmori1_room_13ActorList_000054[];
extern PolygonType0 Bmori1_room_13PolygonType0_0000E0;
extern PolygonDlist Bmori1_room_13PolygonDlist_0000EC[1];
extern s32 Bmori1_room_13_terminatorMaybe_0000F4;
extern Vtx Bmori1_room_13Vtx_000100[];
extern Gfx Bmori1_room_13DL_001F70[];
extern Vtx Bmori1_room_13Vtx_003E38[];
extern Gfx Bmori1_room_13DL_0044B8[];
extern Gfx Bmori1_room_13DL_004CB8[];
extern u64 Bmori1_room_13Tex_004CD0[];
extern u64 Bmori1_room_13Tex_0054D0[];
extern u64 Bmori1_room_13Tex_005CD0[];
extern u64 Bmori1_room_13Tex_0064D0[];
extern u64 Bmori1_room_13Tex_006CD0[];
extern u64 Bmori1_room_13Tex_0074D0[];
extern u64 Bmori1_room_13Tex_0078D0[];
extern Vtx Bmori1_room_13Vtx_0080D0[];
extern Gfx Bmori1_room_13DL_0081D0[];
extern Gfx Bmori1_room_13DL_008298[];
extern u64 Bmori1_room_13Tex_0082A8[];

#endif

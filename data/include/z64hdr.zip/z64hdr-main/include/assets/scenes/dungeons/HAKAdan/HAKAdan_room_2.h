#ifndef HAKADAN_ROOM_2_H
#define HAKADAN_ROOM_2_H 1

extern SceneCmd HAKAdan_room_2Commands[];
extern s16 HAKAdan_room_2ObjectList_000040[];
extern ActorEntry HAKAdan_room_2ActorList_00004C[];
extern PolygonType2 HAKAdan_room_2PolygonType2_0001A0;
extern PolygonDlist2 HAKAdan_room_2PolygonDlist2_0001AC[9];
extern s32 HAKAdan_room_2_terminatorMaybe_00023C;
extern Vtx HAKAdan_room_2Vtx_000240[];
extern Gfx HAKAdan_room_2DL_000A50[];
extern Vtx HAKAdan_room_2Vtx_000C88[];
extern Gfx HAKAdan_room_2DL_002248[];
extern Vtx HAKAdan_room_2Vtx_002790[];
extern Gfx HAKAdan_room_2DL_003570[];
extern Vtx HAKAdan_room_2Vtx_003C30[];
extern Gfx HAKAdan_room_2DL_004960[];
extern Vtx HAKAdan_room_2Vtx_0050A0[];
extern Gfx HAKAdan_room_2DL_005260[];
extern Vtx HAKAdan_room_2Vtx_0053A8[];
extern Gfx HAKAdan_room_2DL_005B28[];
extern Vtx HAKAdan_room_2Vtx_005D28[];
extern Gfx HAKAdan_room_2DL_006158[];
extern Vtx HAKAdan_room_2Vtx_0062E8[];
extern Gfx HAKAdan_room_2DL_006828[];
extern Vtx HAKAdan_room_2Vtx_0069B0[];
extern Gfx HAKAdan_room_2DL_006A90[];
extern u64 HAKAdan_room_2Tex_006BD8[];
extern u64 HAKAdan_room_2Tex_0073D8[];
extern u64 HAKAdan_room_2Tex_0077D8[];
extern u64 HAKAdan_room_2Tex_007FD8[];
extern u64 HAKAdan_room_2Tex_0081D8[];
extern u64 HAKAdan_room_2Tex_0091D8[];
extern u64 HAKAdan_room_2Tex_0099D8[];
extern u64 HAKAdan_room_2Tex_009BD8[];
extern u64 HAKAdan_room_2Tex_00A3D8[];
extern u64 HAKAdan_room_2Tex_00A5D8[];
extern u64 HAKAdan_room_2Tex_00A7D8[];

#endif

#ifndef BMORI1_ROOM_18_H
#define BMORI1_ROOM_18_H 1

extern SceneCmd Bmori1_room_18Commands[];
extern s16 Bmori1_room_18ObjectList_000040[];
extern ActorEntry Bmori1_room_18ActorList_000050[];
extern PolygonType0 Bmori1_room_18PolygonType0_000070;
extern PolygonDlist Bmori1_room_18PolygonDlist_00007C[1];
extern s32 Bmori1_room_18_terminatorMaybe_000084;
extern Vtx Bmori1_room_18Vtx_000090[];
extern Gfx Bmori1_room_18DL_000590[];
extern Gfx Bmori1_room_18DL_000B20[];
extern u64 Bmori1_room_18Tex_000B30[];

#endif

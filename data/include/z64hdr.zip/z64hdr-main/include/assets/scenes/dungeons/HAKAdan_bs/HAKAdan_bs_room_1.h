#ifndef HAKADAN_BS_ROOM_1_H
#define HAKADAN_BS_ROOM_1_H 1

extern SceneCmd HAKAdan_bs_room_1Commands[];
extern s16 HAKAdan_bs_room_1ObjectList_000040[];
extern ActorEntry HAKAdan_bs_room_1ActorList_00004C[];
extern PolygonType0 HAKAdan_bs_room_1PolygonType0_000060;
extern PolygonDlist HAKAdan_bs_room_1PolygonDlist_00006C[1];
extern s32 HAKAdan_bs_room_1_terminatorMaybe_000074;
extern Vtx HAKAdan_bs_room_1Vtx_000080[];
extern Gfx HAKAdan_bs_room_1DL_000C00[];
extern Vtx HAKAdan_bs_room_1Vtx_000FE0[];
extern Gfx HAKAdan_bs_room_1DL_0013C0[];
extern Vtx HAKAdan_bs_room_1Vtx_001508[];
extern Gfx HAKAdan_bs_room_1DL_001848[];
extern Vtx HAKAdan_bs_room_1Vtx_0019F0[];
extern Gfx HAKAdan_bs_room_1DL_002540[];
extern Vtx HAKAdan_bs_room_1Vtx_002868[];
extern Gfx HAKAdan_bs_room_1DL_002BE8[];
extern Gfx HAKAdan_bs_room_1DL_002D20[];
extern u64 HAKAdan_bs_room_1Tex_002D50[];
extern u64 HAKAdan_bs_room_1Tex_002F50[];
extern u64 HAKAdan_bs_room_1Tex_003750[];
extern u64 HAKAdan_bs_room_1Tex_003F50[];
extern u64 HAKAdan_bs_room_1Tex_004F50[];

#endif

#ifndef ALLOCA_H
#define ALLOCA_H

void* alloca(u32);
#define alloca  __builtin_alloca

#endif
